######Projekt: Treibende Kr�fte im Freizeitverkehr
######Autoren Studie: Ueli Haefeli, Tobias Arnold (Interface), Martin Lutzenberberger (Swiss Economics), Konrad G�tz (ISOE), Julian Fleury (Transitec)
######Autor R-Script: Tobias Arnold
######Letzte �nderung R-Script: 21.01.2021



####Packages laden####
rm(list = ls())
library(cluster)
library(descr)
library(dplyr)
library(expss)
library(foreign)
library(ggplot2)
library(gridExtra)
library(Hmisc)
library(mosaic)
library(nnet)
library(openxlsx)
library(plyr)
library(poLCA)
library(psych)
library(questionr)
library(sjlabelled)
library(sjPlot)
library(stargazer)
library(stats)
library(summarytools)
library(tidyr)
library(tidyverse)
library(weights)
library(xtable)
library(xlsx)

#####################x
####Vorbemerkungen####
#####################x

#In diesem R-Script finden sich alle Codes f�r die Kapitel 3 bis 6 der Studie "Treibende Kr�fte des Freizeitverkehrs".
#Die in diesem Script verwendeten Daten sind alle auf GitHub hinterlegt und zur freien Verwendung freigegeben.


########################################################################################################x
####Kapitel 3: Motive, Orientierungen und Verhalten der Akteure im Freizeitverkehr (Cluster Analyse)####
########################################################################################################x

####Datensatz laden und Codebuch generieren####
data_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Rohdaten/Datensatz_Erhebung_Treiber des Freizeitverkehrs.sav",to.data.frame=FALSE,use.value.labels=FALSE)
data <- as.data.frame(data_roh)
data_varlabel <- attr(data_roh,"variable.labels") #Liste mit Variablenlabels wird erstellt
data_varlabel <- as.data.frame(data_varlabel) 
data_valuelabel <- attr(data_roh,"label.table") #Liste mit Wertelabels wird erstellt
data_roh <- NULL


####Durchf�hrung der Faktorenanalyse####
#Faktorenanalyse f�r Variablen zu MOtiven
keeps <- c("IDNR", "WT", "Q71_1", "Q71_2", "Q71_3", "Q71_4", "Q71_5", "Q71_6", "Q71_7", "Q71_8", "Q71_9", "Q71_10") #Variablen, die behalten werden sollen, benennen.
data_motive <- data[keeps] #Datensatz auf die Liste der Variablen im Objekt "keeps" reduzieren.
data_motive$Q71_1[data_motive$Q71_1==98] <- NA #Die Antworten "Weiss nicht" (=98) und "keine Angabe" (=99) werden f�r diese und alle nachfolgenden Variablen als Missing definiert.
data_motive$Q71_1[data_motive$Q71_1==99] <- NA
data_motive$Q71_2[data_motive$Q71_2==98] <- NA
data_motive$Q71_2[data_motive$Q71_2==99] <- NA
data_motive$Q71_3[data_motive$Q71_3==98] <- NA
data_motive$Q71_3[data_motive$Q71_3==99] <- NA
data_motive$Q71_4[data_motive$Q71_4==98] <- NA
data_motive$Q71_4[data_motive$Q71_4==99] <- NA
data_motive$Q71_5[data_motive$Q71_5==98] <- NA
data_motive$Q71_5[data_motive$Q71_5==99] <- NA
data_motive$Q71_6[data_motive$Q71_6==98] <- NA
data_motive$Q71_6[data_motive$Q71_6==99] <- NA
data_motive$Q71_7[data_motive$Q71_7==98] <- NA
data_motive$Q71_7[data_motive$Q71_7==99] <- NA
data_motive$Q71_8[data_motive$Q71_8==98] <- NA
data_motive$Q71_8[data_motive$Q71_8==99] <- NA
data_motive$Q71_9[data_motive$Q71_9==98] <- NA
data_motive$Q71_9[data_motive$Q71_9==99] <- NA
data_motive$Q71_10[data_motive$Q71_10==98] <- NA
data_motive$Q71_10[data_motive$Q71_10==99] <- NA
data_motive <- na.omit(data_motive) #F�lle mit mindestens einem Missing ausschliessen.
pca <- psych::principal(data_motive[,3:12], rotate="varimax", nfactors=10, scores=TRUE) #Faktorenanalyse f�r alle Faktoren durchf�hren mit der Varimax-Rotationsmethode
print(pca$values) #Eigenvalues anzeigen lassen: 3 Faktoren sind ideal.
pca <- psych::principal(data_motive[,3:12], rotate="varimax", nfactors=3, scores=TRUE) #Faktorenanalyse f�r 3 Faktoren durchf�hren mit der Varimax-Rotationsmethode
pca.pred <- pca$scores #Faktorwerte f�r die einzelnen F�lle abspeichern und...
data_motive <- cbind(data_motive,pca.pred)#...mit dem Datensatz f�r die Faktoranalyse verbinden.
data_motive <- rename.variable(data_motive,"RC1","motive_pc1")
data_motive <- rename.variable(data_motive,"RC2","motive_pc2")
data_motive <- rename.variable(data_motive,"RC3","motive_pc3")
cor_matrix_motive <- cor(data_motive)
write.xlsx2(cor_matrix_motive,"P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Korrelationsmatrix_pca.xlsx",sheetName="Motive",col.names=TRUE) #Ergebnisse der Faktorenanalyse als Excel-Tabellenblatt abspeichern
#ACHTUNG: Aus inhaltlichen Gr�nden wurde f�r die Berichterstattung eine andere Rangfolge bei der Nummerierung der Faktoren gew�hlt.

#Faktorenanalyse f�r die Variablen zu den Freizeitorientierungen. 
keeps <- c("IDNR", "WT", "Q73_1", "Q73_2", "Q73_3", "Q73_4", "Q73_5", "Q73_6", "Q73_7", "Q73_8", "Q73_9", "Q73_10") #Variablen, die behalten werden sollen, benennen.
data_fo <- data[keeps] #Datensatz auf die Liste der Variablen im Objekt "keeps" reduzieren.
data_fo$Q73_1[data_fo$Q73_1==98] <- NA #Die Antworten "Weiss nicht" (=98) und "keine Angabe" (=99) werden f�r diese und alle nachfolgenden Variablen als Missing definiert.
data_fo$Q73_1[data_fo$Q73_1==99] <- NA
data_fo$Q73_2[data_fo$Q73_2==98] <- NA
data_fo$Q73_2[data_fo$Q73_2==99] <- NA
data_fo$Q73_3[data_fo$Q73_3==98] <- NA
data_fo$Q73_3[data_fo$Q73_3==99] <- NA
data_fo$Q73_4[data_fo$Q73_4==98] <- NA
data_fo$Q73_4[data_fo$Q73_4==99] <- NA
data_fo$Q73_5[data_fo$Q73_5==98] <- NA
data_fo$Q73_5[data_fo$Q73_5==99] <- NA
data_fo$Q73_6[data_fo$Q73_6==98] <- NA
data_fo$Q73_6[data_fo$Q73_6==99] <- NA
data_fo$Q73_7[data_fo$Q73_7==98] <- NA
data_fo$Q73_7[data_fo$Q73_7==99] <- NA
data_fo$Q73_8[data_fo$Q73_8==98] <- NA
data_fo$Q73_8[data_fo$Q73_8==99] <- NA
data_fo$Q73_9[data_fo$Q73_9==98] <- NA
data_fo$Q73_9[data_fo$Q73_9==99] <- NA
data_fo$Q73_10[data_fo$Q73_10==98] <- NA
data_fo$Q73_10[data_fo$Q73_10==99] <- NA
data_fo <- na.omit(data_fo) #F�lle mit mindestens einem Missing ausschliessen.
pca <- psych::principal(data_fo[,3:12], rotate="varimax", nfactors=10, scores=TRUE) #Faktorenanalyse f�r alle Faktoren durchf�hren mit der Varimax-Rotationsmethode
print(pca$values) #Eigenvalues anzeigen lassen: 3 Faktoren sind ideal
pca <- psych::principal(data_fo[,3:12], rotate="varimax", nfactors=3, scores=TRUE) #Faktorenanalyse f�r 3 Faktoren durchf�hren mit der Varimax-Rotationsmethode
pca.pred <- pca$scores #Faktorwerte f�r die einzelnen F�lle abspeichern und...
data_fo <- cbind(data_fo,pca.pred)#...mit dem Datensatz f�r die Faktoranalyse verbinden.
data_fo <- rename.variable(data_fo,"RC1","fo_pc1")
data_fo <- rename.variable(data_fo,"RC2","fo_pc2")
data_fo <- rename.variable(data_fo,"RC3","fo_pc3")
cor_matrix_fo <- cor(data_fo)
write.xlsx2(cor_matrix_fo,"P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Korrelationsmatrix_pca.xlsx",sheetName="Freizeitorientierungen",col.names=TRUE, append = TRUE) #Ergebnisse der Faktorenanalyse als Excel-Tabellenblatt abspeichern

#Extrahierte Faktoren mit Datensatz mergen
pca <- NULL #Objekt pca l�schen
pca.pred <- NULL #Objekt pca.pred l�schen
data_cluster <- merge(data_motive, data_fo, by=c("IDNR"), all=T) #Ergenisse zu den beiden Faktorenanalysen mergen
data_cluster <- na.omit(data_cluster) #F�lle mit mindestens einem Missing ausschliessen
data_cluster$WT <- data_cluster$WT.x
data_motive <- NULL #Objekt data_motive l�schen
data_fo <- NULL #Objekt data_fo l�schen
data_cluster$WT.x <- NULL #Variable WT.x l�schen
data_cluster$WT.y <- NULL #Variable WT.y l�schen




####Durchf�hrung der Cluster Analyse (k-means-Verfahren)####
keeps <- c("IDNR", "WT", "motive_pc1", "motive_pc2", "motive_pc3", "fo_pc1", "fo_pc2", "fo_pc3") #Variablen, die behalten werden sollen, benennen.
data_kcluster <- data_cluster[keeps] #Datensatz auf die Liste der Variablen im Objekt "keeps" reduzieren.
kcluster3 <- kmeans(data_kcluster[,3:8], 3) #Die 3-Cluster-L�sung ausgeben
kcluster4 <- kmeans(data_kcluster[,3:8], 4) #Die 4-Cluster-L�sung ausgeben
data_kcluster$kcluster3 <- as.factor(kcluster3$cluster) #Die Ergebnisse der Cluster Analyse (3 Cluster) als Faktoren abspeichern.
data_kcluster$kcluster4 <- as.factor(kcluster4$cluster) #Die Ergebnisse der Cluster Analyse (4 Cluster) als Faktoren abspeichern.
keeps <- c("IDNR", "WT", "kcluster3", "kcluster4") #Variablen, die behalten werden sollen, benennen.
data_kcluster <- data_kcluster[keeps] #Datensatz auf die Liste der Variablen im Objekt "keeps" reduzieren.
data_kcluster$WT <- NULL #Variable WT l�schen
data_cluster <- merge(data_cluster, data_kcluster, by=c("IDNR"), all=T) #Alle Cluster-L�sungen werden nun gemergt und es wird aufger�umt
cl <- NULL
cld <- NULL
kcluster3 <- NULL
kcluster4 <- NULL

#Sicherstellen, dass Datensatz numerisch ist und Datensatz inkl. Cluster-Zuordnungen abspeichern
data_cluster$Q71_1 <- as.numeric(as.character(data_cluster$Q71_1)) 
data_cluster$Q71_2 <- as.numeric(as.character(data_cluster$Q71_2)) 
data_cluster$Q71_3 <- as.numeric(as.character(data_cluster$Q71_3)) 
data_cluster$Q71_4 <- as.numeric(as.character(data_cluster$Q71_4)) 
data_cluster$Q71_5 <- as.numeric(as.character(data_cluster$Q71_5)) 
data_cluster$Q71_6 <- as.numeric(as.character(data_cluster$Q71_6)) 
data_cluster$Q71_7 <- as.numeric(as.character(data_cluster$Q71_7)) 
data_cluster$Q71_8 <- as.numeric(as.character(data_cluster$Q71_8)) 
data_cluster$Q71_9 <- as.numeric(as.character(data_cluster$Q71_9)) 
data_cluster$Q71_10 <- as.numeric(as.character(data_cluster$Q71_10)) 
data_cluster$motive_pc1 <- as.numeric(as.character(data_cluster$motive_pc1))
data_cluster$motive_pc2 <- as.numeric(as.character(data_cluster$motive_pc2))
data_cluster$motive_pc3 <- as.numeric(as.character(data_cluster$motive_pc3))
data_cluster$Q73_1 <- as.numeric(as.character(data_cluster$Q73_1)) 
data_cluster$Q73_2 <- as.numeric(as.character(data_cluster$Q73_2)) 
data_cluster$Q73_3 <- as.numeric(as.character(data_cluster$Q73_3)) 
data_cluster$Q73_4 <- as.numeric(as.character(data_cluster$Q73_4)) 
data_cluster$Q73_5 <- as.numeric(as.character(data_cluster$Q73_5)) 
data_cluster$Q73_6 <- as.numeric(as.character(data_cluster$Q73_6)) 
data_cluster$Q73_7 <- as.numeric(as.character(data_cluster$Q73_7)) 
data_cluster$Q73_8 <- as.numeric(as.character(data_cluster$Q73_8)) 
data_cluster$Q73_9 <- as.numeric(as.character(data_cluster$Q73_9)) 
data_cluster$Q73_10 <- as.numeric(as.character(data_cluster$Q73_10))
data_cluster$fo_pc1 <- as.numeric(as.character(data_cluster$fo_pc1))
data_cluster$fo_pc2 <- as.numeric(as.character(data_cluster$fo_pc2))
data_cluster$fo_pc3 <- as.numeric(as.character(data_cluster$fo_pc3))
write.csv(data_cluster, file = "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/D_Cluster.csv")


####Deskription der Cluster: Faktoren####
#3-Cluster-L�sung
kcluster3 <- aggregate(data_cluster, by = list(data_cluster$kcluster3),FUN = mean) #Mittelwert der Faktoren pro Cluster berechnen
keeps <- c("kcluster3", "motive_pc1", "motive_pc2", "motive_pc3", "fo_pc1", "fo_pc2", "fo_pc3") #Variablen, die behalten werden sollen, benennen.
kcluster3 <- kcluster3[keeps] #Datensatz auf die Liste der Variablen im Objekt "keeps" reduzieren.
kcluster3_n <- aggregate(data_cluster, by = list(data_cluster$kcluster3),FUN = length) #Die Anzahl Personen pro Cluster ausweisen lassen
keeps <- c("IDNR")
kcluster3_n <- kcluster3_n[keeps]
kcluster3_n <- rename.variable(kcluster3_n, "IDNR", "n") #Die Anzahl Personen pro Cluster als Variable abspeichern...
kcluster3 <- cbind(kcluster3,kcluster3_n) #...und die neue Variable an die Tabelle mit den Mittelwerten der Faktoren pro Cluster anf�gen.
write.xlsx2(kcluster3, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/cluster_outputs.xlsx", sheetName="kcluster3", append=TRUE) #Mittelwert der Faktoren pro Cluster in Excel abspeichern
#4-Cluster-L�sung
kcluster4 <- aggregate(data_cluster, by = list(data_cluster$kcluster4),FUN = mean) #Mittelwert der Faktoren pro Cluster berechnen
keeps <- c("kcluster4", "motive_pc1", "motive_pc2", "motive_pc3", "fo_pc1", "fo_pc2", "fo_pc3")
kcluster4 <- kcluster4[keeps]
kcluster4_n <- aggregate(data_cluster, by = list(data_cluster$kcluster4),FUN = length)
keeps <- c("IDNR")
kcluster4_n <- kcluster4_n[keeps]
kcluster4_n <- rename.variable(kcluster4_n, "IDNR", "n")
kcluster4 <- cbind(kcluster4,kcluster4_n)
write.xlsx2(kcluster4, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/cluster_outputs.xlsx", sheetName="kcluster4", append=TRUE) #Mittelwert der Faktoren pro Cluster in Excel abspeichern
#ACHTUNG: Da es sich beim k-means Verfahren f�r die Cluster Analyse um ein iteratives Verfahren handelt, k�nnen die Ergebnisse ganz leicht, im Kommabereich, von den Ergebnissen im Bericht abweichen.

####Deskription der Cluster: Items####
#3-Cluster-L�sung
kcluster3 <- aggregate(data_cluster, by = list(data_cluster$kcluster3),FUN = mean) #Mittelwert der Items pro Cluster berechnen
keeps <- c("Q71_1", "Q71_2", "Q71_3", "Q71_4", "Q71_5", "Q71_6", "Q71_7", "Q71_8", "Q71_9", "Q71_10", 
           "Q72_1", "Q72_2", "Q72_3", "Q72_4", "Q72_5", "Q72_6", "Q72_7",
           "Q73_1", "Q73_2", "Q73_3", "Q73_4", "Q73_5", "Q73_6", "Q73_7", "Q73_8", "Q73_9", "Q73_10")
kcluster3 <- kcluster3[keeps]
kcluster3_n <- aggregate(data_cluster, by = list(data_cluster$kcluster3),FUN = length)
keeps <- c("IDNR")
kcluster3_n <- kcluster3_n[keeps]
kcluster3_n <- rename.variable(kcluster3_n, "IDNR", "n")
kcluster3 <- cbind(kcluster3,kcluster3_n)
write.xlsx2(kcluster3, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/cluster_outputs_items.xlsx", sheetName="kcluster3", append=TRUE)

#4-Cluster-L�sung
kcluster4 <- aggregate(data_cluster, by = list(data_cluster$kcluster4),FUN = mean) #Mittelwert der Items pro Cluster berechnen
keeps <- c("Q71_1", "Q71_2", "Q71_3", "Q71_4", "Q71_5", "Q71_6", "Q71_7", "Q71_8", "Q71_9", "Q71_10", 
           "Q72_1", "Q72_2", "Q72_3", "Q72_4", "Q72_5", "Q72_6", "Q72_7",
           "Q73_1", "Q73_2", "Q73_3", "Q73_4", "Q73_5", "Q73_6", "Q73_7", "Q73_8", "Q73_9", "Q73_10")
kcluster4 <- kcluster4[keeps]
kcluster4_n <- aggregate(data_cluster, by = list(data_cluster$kcluster4),FUN = length)
keeps <- c("IDNR")
kcluster4_n <- kcluster4_n[keeps]
kcluster4_n <- rename.variable(kcluster4_n, "IDNR", "n")
kcluster4 <- cbind(kcluster4,kcluster4_n)
write.xlsx2(kcluster4, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/cluster_outputs_items.xlsx", sheetName="kcluster4", append=TRUE)


####Deskription der Cluster: Soziodemografie, Mobilit�tswerkzeuge, Mobilit�tsverhalten, Freizeitverhalten####
#Variablen aufbereiten
data$Q71_1[data$Q71_1==98] <- NA #F�r die Variablen Q72_1 bis Q72_10 m�ssen die Missing Values definiert werden.
data$Q71_1[data$Q71_1==99] <- NA #Ansonsten k�nnen die Variablen so belassen werden.
data$Q71_2[data$Q71_2==98] <- NA
data$Q71_2[data$Q71_2==99] <- NA
data$Q71_3[data$Q71_3==98] <- NA
data$Q71_3[data$Q71_3==99] <- NA
data$Q71_4[data$Q71_4==98] <- NA
data$Q71_4[data$Q71_4==99] <- NA
data$Q71_5[data$Q71_5==98] <- NA
data$Q71_5[data$Q71_5==99] <- NA
data$Q71_6[data$Q71_6==98] <- NA
data$Q71_6[data$Q71_6==99] <- NA
data$Q71_7[data$Q71_7==98] <- NA
data$Q71_7[data$Q71_7==99] <- NA
data$Q71_8[data$Q71_8==98] <- NA
data$Q71_8[data$Q71_8==99] <- NA
data$Q71_9[data$Q71_9==98] <- NA
data$Q71_9[data$Q71_9==99] <- NA
data$Q71_10[data$Q71_10==98] <- NA
data$Q71_10[data$Q71_10==99] <- NA
data$Q72_1[data$Q72_1==98] <- NA#F�r die Variablen Q72_1 bis Q72_7 m�ssen die Missing Values definiert werden.
data$Q72_1[data$Q72_1==99] <- NA
data$Q72_2[data$Q72_2==98] <- NA
data$Q72_2[data$Q72_2==99] <- NA
data$Q72_3[data$Q72_3==98] <- NA
data$Q72_3[data$Q72_3==99] <- NA
data$Q72_4[data$Q72_4==98] <- NA
data$Q72_4[data$Q72_4==99] <- NA
data$Q72_5[data$Q72_5==98] <- NA
data$Q72_5[data$Q72_5==99] <- NA
data$Q72_6[data$Q72_6==98] <- NA
data$Q72_6[data$Q72_6==99] <- NA
data$Q72_7[data$Q72_7==98] <- NA
data$Q72_7[data$Q72_7==99] <- NA
data$Q103[data$Q103==98] <- NA #'Weiss nicht' bei Frage nach Wohnsituation wird auf NA gesetzt
data$Q103[data$Q103==99] <- NA #'Keine Antwort' bei Frage nach Wohnsituation wird auf NA gesetzt
table(data$AGEGRP) #Variable zu Alter in Gruppen kann so belassen werden
table(data$SEX) #Variable zu Geschlecht kann so belassen werden
data$Q103[data$Q1012==98] <- NA #'Weiss nicht' bei Frage nach Bildungsabschluss wird auf NA gesetzt
data$Q103[data$Q1012==99] <- NA #'Keine Antwort' bei Frage nach Bildungsabschluss wird auf NA gesetzt
data_cluster$WT <- NULL
data <- merge(data, data_cluster, by="IDNR", all=T) #Daten weden gemergt


#Auswertungen vornehmen
#Auswertung "Wohnform" nach Cluster
ct3_wohnform <- reshape2::dcast(data, Q103 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "Q103"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Auswertung "Alter" nach Cluster
ct3_alter <- reshape2::dcast(data, AGEGRP ~ kcluster3, value.var= "WT", margins=c("kcluster3", "AGEGRP"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Auswertung "Geschlecht" nach Cluster
ct3_geschlecht <- reshape2::dcast(data, SEX ~ kcluster3, value.var= "WT", margins=c("kcluster3", "SEX"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Auswertung "Einkommen" nach Cluster
ct3_einkommen <- reshape2::dcast(data, Q1011 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "Q1011"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Auswertung "Ausbildung" nach Cluster
ct3_ausbildung <- reshape2::dcast(data, Q1012 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "Q1012"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Alles zusammenf�hren
cluster3_soziodem <- bind_rows(ct3_wohnform, ct3_alter, ct3_geschlecht, ct3_einkommen, ct3_ausbildung)


#Auswertung der Variablen zu Mobilit�tswerkzeugen nach Cluster
#Besitz von Fahrausweis
data$fahrausweis[data$Q101_1==2] <- 0 
data$fahrausweis[data$Q101_1==1] <- 1
data$fahrausweis[data$Q101_1==98] <- NA
data$fahrausweis[data$Q101_1==99] <- NA
ct3_fahrausweis <- reshape2::dcast(data, fahrausweis ~ kcluster3, value.var= "WT", margins=c("kcluster3", "fahrausweis"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Besitz von OEV-Abo
data$halbtax[data$Q101_3==2] <- 0
data$halbtax[data$Q101_3==1] <- 1
data$halbtax[data$Q101_3==98] <- NA
data$halbtax[data$Q101_3==99] <- NA
data$ga[data$Q101_4==2] <- 0
data$ga[data$Q101_4==1] <- 1
data$ga[data$Q101_4==98] <- NA
data$ga[data$Q101_4==99] <- NA  
data$verbundabo[data$Q101_5==2] <- 0
data$verbundabo[data$Q101_5==1] <- 1
data$verbundabo[data$Q101_5==98] <- NA
data$verbundabo[data$Q101_5==99] <- NA  
data$oev_abo <- with(data, ifelse(data$halbtax==1 | data$ga ==1 | data$verbundabo==1, 1, 0))
ct3_oev_abo <- reshape2::dcast(data, oev_abo ~ kcluster3, value.var= "WT", margins=c("kcluster3", "oev_abo"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Mobility-Mitgliedschaft
data$mobility[data$Q101_6==2] <- 0
data$mobility[data$Q101_6==1] <- 1
data$mobility[data$Q101_6==98] <- NA
data$mobility[data$Q101_6==99] <- NA  
ct3_mobility <- reshape2::dcast(data, mobility ~ kcluster3, value.var= "WT", margins=c("kcluster3", "mobility"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#PW-Zugriff
data$pw[data$Q102==1] <- 0
data$pw[data$Q102==2] <- 1
data$pw[data$Q102==3] <- 1
data$pw[data$Q102==98] <- NA
ct3_pw <- reshape2::dcast(data, pw ~ kcluster3, value.var= "WT", margins=c("kcluster3", "pw"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Alles zusammenf�hren
cluster3_mwerkzeuge <- bind_rows(ct3_fahrausweis, ct3_oev_abo, ct3_mobility, ct3_pw)


#Auswertung der Variablen zu Mobilit�tsverhalten (allt�gliche Freizeit) nach Cluster
#Verkehrsmittel f�r Gastronomiebesuch
data$vm_gastro <- data$Q14
data$vm_gastro[data$Q11==1 & data$Q13==1]<-1
data$vm_gastro[data$Q11==2 & data$Q13==1]<-2
data$vm_gastro[data$Q11==3 & data$Q13==1]<-3
data$vm_gastro[data$Q11==4 & data$Q13==1]<-4
data$vm_gastro[data$Q11==5 & data$Q13==1]<-5
data$vm_gastro[data$Q11==6 & data$Q13==1]<-6
data$vm_gastro[data$Q11==7 & data$Q13==1]<-7
data$vm_gastro[data$Q11==8 & data$Q13==1]<-8
data$vm_gastro[data$Q11==9 & data$Q13==1]<-9
data$vm_gastro[data$Q11==10 & data$Q13==1]<-10
data$vm_gastro[data$Q11==11 & data$Q13==1]<-11
data$vm_gastro[data$Q13==3] <- 12
data$vm_gastro[data$Q13==98] <- NA
data$vm_gastro[data$Q13==99] <- NA
data$dv1[data$vm_gastro==1] <- 1 
data$dv1[data$vm_gastro==2] <- 1
data$dv1[data$vm_gastro==3] <- 2
data$dv1[data$vm_gastro==4] <- 2
data$dv1[data$vm_gastro==6] <- 3
data$dv1[data$vm_gastro==7] <- 3
data$dv1[data$vm_gastro==11] <- NA
data$dv1[data$vm_gastro==12] <- 4
data$dv1 <- as.factor(data$dv1)
table(data$dv1)
data$dv1 <- revalue(data$dv1, c("1" = "LV", "2" = "MIV", "3" = "�V", "4" = "Multimodal"))
ct3_dv1 <- reshape2::dcast(data, dv1 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "dv1"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.

#Verkehrsmittel f�r kulturelle Veranstaltungen/sportlicher Anlass
data$vm_veranstaltung <- data$Q24
data$vm_veranstaltung[data$Q21==1 & data$Q23==1]<-1
data$vm_veranstaltung[data$Q21==2 & data$Q23==1]<-2
data$vm_veranstaltung[data$Q21==3 & data$Q23==1]<-3
data$vm_veranstaltung[data$Q21==4 & data$Q23==1]<-4
data$vm_veranstaltung[data$Q21==5 & data$Q23==1]<-5
data$vm_veranstaltung[data$Q21==6 & data$Q23==1]<-6
data$vm_veranstaltung[data$Q21==7 & data$Q23==1]<-7
data$vm_veranstaltung[data$Q21==8 & data$Q23==1]<-8
data$vm_veranstaltung[data$Q21==9 & data$Q23==1]<-9
data$vm_veranstaltung[data$Q21==10 & data$Q23==1]<-10
data$vm_veranstaltung[data$Q21==11 & data$Q23==1]<-11
data$vm_veranstaltung[data$Q23==3] <- 12
data$vm_veranstaltung[data$Q23==98] <- NA
data$vm_veranstaltung[data$Q23==99] <- NA
data$dv2[data$vm_veranstaltung==1] <- 1 
data$dv2[data$vm_veranstaltung==2] <- 1
data$dv2[data$vm_veranstaltung==3] <- 2
data$dv2[data$vm_veranstaltung==4] <- 2
data$dv2[data$vm_veranstaltung==5] <- 2
data$dv2[data$vm_veranstaltung==6] <- 3
data$dv2[data$vm_veranstaltung==7] <- 3
data$dv2[data$vm_veranstaltung==11] <- NA
data$dv2[data$vm_veranstaltung==12] <- 4
data$dv2 <- as.factor(data$dv2)
table(data$dv2)
data$dv2 <- revalue(data$dv2, c("1" = "LV", "2" = "MIV", "3" = "�V", "4" = "Multimodal"))
ct3_dv2 <- reshape2::dcast(data, dv2 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "dv2"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.

#Verkehrsmittel f�r sportliche Aussenaktivit�t
data$vm_sport <- data$Q34
data$vm_sport[data$Q31==1 & data$Q33==1]<-1
data$vm_sport[data$Q31==2 & data$Q33==1]<-2
data$vm_sport[data$Q31==3 & data$Q33==1]<-3
data$vm_sport[data$Q31==4 & data$Q33==1]<-4
data$vm_sport[data$Q31==5 & data$Q33==1]<-5
data$vm_sport[data$Q31==6 & data$Q33==1]<-6
data$vm_sport[data$Q31==7 & data$Q33==1]<-7
data$vm_sport[data$Q31==8 & data$Q33==1]<-8
data$vm_sport[data$Q31==9 & data$Q33==1]<-9
data$vm_sport[data$Q31==10 & data$Q33==1]<-10
data$vm_sport[data$Q31==11 & data$Q33==1]<-11
data$vm_sport[data$Q33==3] <- 12
data$vm_sport[data$Q33==98] <- NA
data$vm_sport[data$Q33==99] <- NA
data$dv3[data$vm_sport==1] <- 1 
data$dv3[data$vm_sport==2] <- 1
data$dv3[data$vm_sport==3] <- 2
data$dv3[data$vm_sport==4] <- 2
data$dv3[data$vm_sport==5] <- 2
data$dv3[data$vm_sport==6] <- 3
data$dv3[data$vm_sport==7] <- 3
data$dv3[data$vm_sport==11] <- NA
data$dv3[data$vm_sport==12] <- 4
data$dv3 <- as.factor(data$dv3)
table(data$dv3)
data$dv3 <- revalue(data$dv3, c("1" = "LV", "2" = "MIV", "3" = "�V", "4" = "Multimodal"))
ct3_dv3 <- reshape2::dcast(data, dv3 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "dv3"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.

#Verkehrsmittel f�r soziale Kontakte
table(data$Q86)
data$vm_kontakt1[data$Q83==1] <- 1 #1 = LV
data$vm_kontakt1[data$Q83==2] <- 1 
data$vm_kontakt1[data$Q83==3] <- 2 #2 = MIV
data$vm_kontakt1[data$Q83==4] <- 2 
data$vm_kontakt1[data$Q83==5] <- 2 
data$vm_kontakt1[data$Q83==6] <- 3 #3 = �V
data$vm_kontakt1[data$Q83==7] <- 3  
data$vm_kontakt1[data$Q83==8] <- 3 
data$vm_kontakt1[data$Q83==9] <- 3 
data$vm_kontakt1[data$Q83==10] <- 3 
data$vm_kontakt1[data$Q83==11] <- NA 
data$vm_kontakt2[data$Q86==1] <- 1 
data$vm_kontakt2[data$Q86==2] <- 1 
data$vm_kontakt2[data$Q86==3] <- 2
data$vm_kontakt2[data$Q86==4] <- 2 
data$vm_kontakt2[data$Q86==5] <- 2 
data$vm_kontakt2[data$Q86==6] <- 3
data$vm_kontakt2[data$Q86==7] <- 3 
data$vm_kontakt2[data$Q86==8] <- 3 
data$vm_kontakt2[data$Q86==9] <- 3 
data$vm_kontakt2[data$Q86==10] <- 3 
data$vm_kontakt2[data$Q86==11] <- NA
data$vm_kontakt3[data$Q89==1] <- 1 
data$vm_kontakt3[data$Q89==2] <- 1 
data$vm_kontakt3[data$Q89==3] <- 2
data$vm_kontakt3[data$Q89==4] <- 2 
data$vm_kontakt3[data$Q89==5] <- 2 
data$vm_kontakt3[data$Q89==6] <- 3
data$vm_kontakt3[data$Q89==7] <- 3 
data$vm_kontakt3[data$Q89==8] <- 3 
data$vm_kontakt3[data$Q89==9] <- 3 
data$vm_kontakt3[data$Q89==10] <- 3 
data$vm_kontakt3[data$Q89==11] <- NA
data$vm_kontakte2 <- data %>% select(contains("vm_kontakt")) %>% apply(1, mean, na.rm = T) # Bei apply auf 1 setzen um zeilenweise Berechnung durchzuf�hren (2 w�re spaltenweise)
data$vm_kontakte <- 4 #Multimodal
data$vm_kontakte[data$vm_kontakte2==1] <- 1
data$vm_kontakte[data$vm_kontakte2==2] <- 2
data$vm_kontakte[data$vm_kontakte2==3] <- 3
data$vm_kontakte[data$vm_kontakte2=="NaN"] <- NA
data$vm_kontakte[data$IDNR==451532] <- 4 #Bei den folgenden F�llen f�hrt der Mittelwert zu einer zwei, dahinter verstecken sich aber je 1x eine 1 und eine 3. Diese werden deshalb von Hand auf eine 4 (multimodal) gesetzt
data$vm_kontakte[data$IDNR==452334] <- 4
data$vm_kontakte[data$IDNR==452387] <- 4
data$vm_kontakte[data$IDNR==452947] <- 4
data$vm_kontakte[data$IDNR==453677] <- 4
data$vm_kontakte[data$IDNR==454079] <- 4
data$vm_kontakte[data$IDNR==455561] <- 4
data$vm_kontakte[data$IDNR==455685] <- 4
data$vm_kontakte[data$IDNR==455720] <- 4
data$vm_kontakte[data$IDNR==455725] <- 4
data$vm_kontakte[data$IDNR==455889] <- 4
data$vm_kontakte[data$IDNR==455913] <- 4
data$vm_kontakte[data$IDNR==455977] <- 4
data$vm_kontakte[data$IDNR==456197] <- 4
data$vm_kontakte[data$IDNR==456489] <- 4
data$vm_kontakte[data$IDNR==456905] <- 4
data$vm_kontakte[data$IDNR==456963] <- 4
data$vm_kontakte[data$IDNR==457629] <- 4
data$vm_kontakte[data$IDNR==458680] <- 4
data$vm_kontakte[data$IDNR==459129] <- 4
data$vm_kontakte[data$IDNR==459371] <- 4
data$vm_kontakte[data$IDNR==459432] <- 4
data$vm_kontakte[data$IDNR==459443] <- 4
data$vm_kontakte[data$IDNR==459444] <- 4
data$vm_kontakte[data$IDNR==459450] <- 4
data$vm_kontakte[data$IDNR==459559] <- 4
data$vm_kontakte[data$IDNR==459905] <- 4
data$vm_kontakte[data$IDNR==451532] <- 4
data$vm_kontakte[data$IDNR==451675] <- 4
data$vm_kontakte[data$IDNR==452298] <- 4
data$vm_kontakte[data$IDNR==452334] <- 4
data$vm_kontakte[data$IDNR==452387] <- 4
data$vm_kontakte[data$IDNR==452947] <- 4
data$vm_kontakte[data$IDNR==453594] <- 4
data$vm_kontakte[data$IDNR==454370] <- 4
data$vm_kontakte[data$IDNR==455685] <- 4
data$vm_kontakte[data$IDNR==455763] <- 4
data$vm_kontakte[data$IDNR==455862] <- 4
data$vm_kontakte[data$IDNR==455913] <- 4
data$vm_kontakte[data$IDNR==455977] <- 4
data$vm_kontakte[data$IDNR==456179] <- 4
data$vm_kontakte[data$IDNR==456197] <- 4
data$vm_kontakte[data$IDNR==456905] <- 4
data$vm_kontakte[data$IDNR==457532] <- 4
data$vm_kontakte[data$IDNR==459371] <- 4
data$vm_kontakte[data$IDNR==459432] <- 4
data$vm_kontakte[data$IDNR==459443] <- 4
data$vm_kontakte[data$IDNR==459559] <- 4
data$vm_kontakte[data$IDNR==451675] <- 4
data$vm_kontakte[data$IDNR==452298] <- 4
data$vm_kontakte[data$IDNR==453594] <- 4
data$vm_kontakte[data$IDNR==453677] <- 4
data$vm_kontakte[data$IDNR==454079] <- 4
data$vm_kontakte[data$IDNR==454370] <- 4
data$vm_kontakte[data$IDNR==455561] <- 4
data$vm_kontakte[data$IDNR==455720] <- 4
data$vm_kontakte[data$IDNR==455725] <- 4
data$vm_kontakte[data$IDNR==455763] <- 4
data$vm_kontakte[data$IDNR==455862] <- 4
data$vm_kontakte[data$IDNR==455889] <- 4
data$vm_kontakte[data$IDNR==456179] <- 4
data$vm_kontakte[data$IDNR==456489] <- 4
data$vm_kontakte[data$IDNR==456963] <- 4
data$vm_kontakte[data$IDNR==457532] <- 4
data$vm_kontakte[data$IDNR==457629] <- 4
data$vm_kontakte[data$IDNR==458680] <- 4
data$vm_kontakte[data$IDNR==459129] <- 4
data$vm_kontakte[data$IDNR==459444] <- 4
data$vm_kontakte[data$IDNR==459450] <- 4
data$vm_kontakte[data$IDNR==459905] <- 4
data$dv4 <- as.factor(data$vm_kontakte)
data$dv4 <- revalue(data$dv4, c("1" = "LV", "2" = "MIV", "3" = "�V", "4" = "Multimodal"))
ct3_dv4 <- reshape2::dcast(data, dv4 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "dv4"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Alles zusammenf�gen
cluster3_mverhalten1 <- bind_rows(ct3_dv1, ct3_dv2, ct3_dv3, ct3_dv4)

#Auswertung der Variablen zu Mobilit�tsverhalten (nicht allt�gliche Freizeit) nach Cluster
#Anzahl Tagesreisen mit dem Auto
data$Q51_1[data$Q51_1>20] <- NA
data$anzahl_tagesreisen_auto <- data$Q51_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_tagesreisen_auto <- aggregate(data$anzahl_tagesreisen_auto, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_tagesreisen_auto <- rename(ct3_anzahl_tagesreisen_auto,c(x="anzahl_tagesreisen_auto"))
data$Q51_2[data$Q51_2>20] <- NA
#Anzahl Tagesreisen mit dem Motorrad
data$anzahl_tagesreisen_motorrad <- data$Q51_2 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_tagesreisen_motorrad <- aggregate(data$anzahl_tagesreisen_motorrad, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_tagesreisen_motorrad <- rename(ct3_anzahl_tagesreisen_motorrad,c(x="anzahl_tagesreisen_motorrad"))
data$Q51_3[data$Q51_3>20] <- NA
#Anzahl Tagesreisen mit dem Zug
data$anzahl_tagesreisen_zug <- data$Q51_3 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_tagesreisen_zug <- aggregate(data$anzahl_tagesreisen_zug, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_tagesreisen_zug <- rename(ct3_anzahl_tagesreisen_zug,c(x="anzahl_tagesreisen_zug"))
data$Q51_4[data$Q51_4>20] <- NA
#Anzahl Tagesreisen mit dem Fernbus
data$anzahl_tagesreisen_fernbus <- data$Q51_4 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_tagesreisen_fernbus <- aggregate(data$anzahl_tagesreisen_fernbus, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_tagesreisen_fernbus <- rename(ct3_anzahl_tagesreisen_fernbus,c(x="anzahl_tagesreisen_fernbus"))
data$Q51_5[data$Q51_5>20] <- NA
#Anzahl Tagesreisen mit dem Tram/Bus
data$anzahl_tagesreisen_tram_bus <- data$Q51_5 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_tagesreisen_tram_bus <- aggregate(data$anzahl_tagesreisen_tram_bus, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_tagesreisen_tram_bus <- rename(ct3_anzahl_tagesreisen_tram_bus,c(x="anzahl_tagesreisen_tram_bus"))
data$Q51_6[data$Q51_6>20] <- NA
#Anzahl Tagesreisen mit dem Schiff
data$anzahl_tagesreisen_schiff <- data$Q51_6 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_tagesreisen_schiff <- aggregate(data$anzahl_tagesreisen_schiff, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_tagesreisen_schiff <- rename(ct3_anzahl_tagesreisen_schiff,c(x="anzahl_tagesreisen_schiff"))
#Anzahl Shopping-Tagesreisen
data$Q52_SHOP_1[data$Q52_SHOP_1>20] <- NA
data$anzahl_shopping_tagesreisen <- data$Q52_SHOP_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_shopping_tagesreisen <- aggregate(data$anzahl_shopping_tagesreisen, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_shopping_tagesreisen <- rename(ct3_anzahl_shopping_tagesreisen,c(x="anzahl_shopping_tagesreisen"))
#Anteil Shopping-Tagesreisen im Ausland
data$Q53[data$Q53>20] <- NA
data$shopping_tagesreisen_anteil_ausland <- data$Q53 * data$WT # mit WT multiplizieren um zu gewichten
ct3_shopping_tagesreisen_anteil_ausland <- aggregate(data$shopping_tagesreisen_anteil_ausland, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_shopping_tagesreisen_anteil_ausland <- rename(ct3_shopping_tagesreisen_anteil_ausland,c(x="shopping_tagesreisen_anteil_ausland"))
#Anzahl Reisen mit �bernachtung mit Auto
data$Q61_1[data$Q61_1>50] <- NA
data$anzahl_reisen_uebernachtung_auto <- data$Q61_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_reisen_uebernachtung_auto <- aggregate(data$anzahl_reisen_uebernachtung_auto, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_reisen_uebernachtung_auto <- rename(ct3_anzahl_reisen_uebernachtung_auto,c(x="anzahl_reisen_uebernachtung_auto"))
#Anzahl Reisen mit �bernachtung mit Zug
data$Q61_2[data$Q61_2>50] <- NA
data$anzahl_reisen_uebernachtung_zug <- data$Q61_2 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_reisen_uebernachtung_zug <- aggregate(data$anzahl_reisen_uebernachtung_zug, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_reisen_uebernachtung_zug <- rename(ct3_anzahl_reisen_uebernachtung_zug,c(x="anzahl_reisen_uebernachtung_zug"))
#Anzahl Reisen mit �bernachtung mit Tram/Bus
data$Q61_3[data$Q61_3>50] <- NA
data$anzahl_reisen_uebernachtung_tram_bus <- data$Q61_3 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_reisen_uebernachtung_tram_bus <- aggregate(data$anzahl_reisen_uebernachtung_tram_bus, by=list(kcluster3$kcluster3ohneoev), mean, na.rm=TRUE)
ct3_anzahl_reisen_uebernachtung_tram_bus <- rename(ct3_anzahl_reisen_uebernachtung_tram_bus,c(x="anzahl_reisen_uebernachtung_tram_bus"))
#Anzahl Reisen mit �bernachtung mit Fernbus
data$Q61_4[data$Q61_4>50] <- NA
data$anzahl_reisen_uebernachtung_fernbus <- data$Q61_4 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_reisen_uebernachtung_fernbus <- aggregate(data$anzahl_reisen_uebernachtung_fernbus, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_reisen_uebernachtung_fernbus <- rename(ct3_anzahl_reisen_uebernachtung_fernbus,c(x="anzahl_reisen_uebernachtung_fernbus"))
#Anzahl Reisen mit �bernachtung mit Flugzeug
data$Q61_5[data$Q61_5>50] <- NA
data$anzahl_reisen_uebernachtung_flugzeug <- data$Q61_5 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_reisen_uebernachtung_flugzeug <- aggregate(data$anzahl_reisen_uebernachtung_flugzeug, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_reisen_uebernachtung_flugzeug <- rename(ct3_anzahl_reisen_uebernachtung_flugzeug,c(x="anzahl_reisen_uebernachtung_flugzeug"))
#Anzahl Reisen mit �bernachtung mit Schiff
data$Q61_6[data$Q61_6>50] <- NA
data$anzahl_reisen_uebernachtung_schiff <- data$Q61_6 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_reisen_uebernachtung_schiff <- aggregate(data$anzahl_reisen_uebernachtung_schiff, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_reisen_uebernachtung_schiff <- rename(ct3_anzahl_reisen_uebernachtung_schiff,c(x="anzahl_reisen_uebernachtung_schiff"))
#Anzahl Kurzstreckenfl�ge
data$Q62_1[data$Q62_1>10] <- NA
data$anzahl_kurzstreckenflug <- data$Q62_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_kurzstreckenflug <- aggregate(data$anzahl_kurzstreckenflug, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_kurzstreckenflug <- rename(ct3_anzahl_kurzstreckenflug,c(x="anzahl_kurzstreckenflug"))
#Anzahl Mittelstreckenfl�ge
data$Q62_2[data$Q62_2>10] <- NA
data$anzahl_mittelstreckenflug <- data$Q62_2 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_mittelstreckenflug <- aggregate(data$anzahl_mittelstreckenflug, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_mittelstreckenflug <- rename(ct3_anzahl_mittelstreckenflug,c(x="anzahl_mittelstreckenflug"))
#Anzahl Langstreckenfl�ge
data$Q62_3[data$Q62_3>10] <- NA
data$anzahl_langstreckenflug <- data$Q62_3 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_langstreckenflug <- aggregate(data$anzahl_langstreckenflug, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_langstreckenflug <- rename(ct3_anzahl_langstreckenflug,c(x="anzahl_langstreckenflug"))
#Alles zusammenf�hren
cluster3_mverhalten2 <- bind_rows(ct3_anzahl_tagesreisen_auto, ct3_anzahl_tagesreisen_motorrad, ct3_anzahl_tagesreisen_zug, ct3_anzahl_tagesreisen_fernbus, ct3_anzahl_tagesreisen_tram_bus, ct3_anzahl_tagesreisen_schiff,
                                  ct3_anzahl_shopping_tagesreisen, ct3_shopping_tagesreisen_anteil_ausland, 
                                  ct3_anzahl_reisen_uebernachtung_auto, ct3_anzahl_reisen_uebernachtung_zug, ct3_anzahl_reisen_uebernachtung_tram_bus, ct3_anzahl_reisen_uebernachtung_fernbus, ct3_anzahl_reisen_uebernachtung_flugzeug, 
                                  ct3_anzahl_reisen_uebernachtung_schiff, ct3_anzahl_kurzstreckenflug, ct3_anzahl_mittelstreckenflug, ct3_anzahl_langstreckenflug)



#Deskription der Cluster: Freizeitverhalten (I)
#Anzahl Gastro-Besuche
data$Q12_1[data$Q12_1>30] <- NA
data$anzahl_gastro <- data$Q12_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_gastro <- aggregate(data$anzahl_gastro, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_gastro <- rename(ct3_anzahl_gastro,c(x="anzahl_gastro"))
#Anzahl Besuche von Veranstaltungen
data$Q22_1[data$Q22_1>30] <- NA
data$anzahl_veranstaltungen <- data$Q22_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_veranstaltungen <- aggregate(data$anzahl_veranstaltungen, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_veranstaltungen <- rename(ct3_anzahl_veranstaltungen,c(x="anzahl_veranstaltungen"))
#Anzahl Besuche von Sportanl�ssen
data$Q32_1[data$Q32_1>30] <- NA
data$anzahl_sport <- data$Q32_1 * data$WT # mit WT multiplizieren um zu gewichten
ct3_anzahl_sport <- aggregate(data$anzahl_sport, by=list(data$kcluster3), mean, na.rm=TRUE)
ct3_anzahl_sport <- rename(ct3_anzahl_sport,c(x="anzahl_sport"))
#Alles zusammenf�hren
cluster3_fv_zwecke <- bind_rows(ct3_anzahl_gastro, ct3_anzahl_veranstaltungen, ct3_anzahl_sport)
#Anzahl Personen mit Zweitwohnsitz
ct3_zweitwohnsitz <- reshape2::dcast(data, Q41 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "Q41"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
ct3_zweitwohnsitz_uebernachtungen <- reshape2::dcast(data, Q42 ~ kcluster3, value.var= "WT", margins=c("kcluster3", "Q42"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.
#Alles zusammenf�hren
cluster3_fv_zwohnung <- bind_rows(ct3_zweitwohnsitz, ct3_zweitwohnsitz_uebernachtungen)


#Deskription der Cluster: Zufriedenheit mit Wohnort
data$wohnort_zufriedenheit[data$Q104==1] <- 4
data$wohnort_zufriedenheit[data$Q104==2] <- 3
data$wohnort_zufriedenheit[data$Q104==3] <- 2
data$wohnort_zufriedenheit[data$Q104==4] <- 1
data$wohnort_zufriedenheit[data$Q104==98] <- NA
data$wohnort_zufriedenheit[data$Q104==99] <- NA
cluster3_wohnort_zufriedenheit <- reshape2::dcast(data, wohnort_zufriedenheit ~ kcluster3, value.var= "WT", margins=c("kcluster3", "wohnort_zufriedenheit"), fun.aggregate = sum) #mit value.var kann die Gewichtung angegeben werden.


#Alle vorherigen Analysen zur Deskription der Cluster in einem Excel abspeichern
write.xlsx2(cluster3_soziodem, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_soziodem", append=FALSE)
write.xlsx2(cluster3_mwerkzeuge, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_mwerkzeuge", append=TRUE)
write.xlsx2(cluster3_mverhalten1, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_mverhalten1", append=TRUE)
write.xlsx2(cluster3_mverhalten2, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_mverhalten2", append=TRUE)
write.xlsx2(cluster3_fv_zwecke, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_fv_zwecke", append=TRUE)
write.xlsx2(cluster3_fv_zwohnung, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_fv_zwohnung", append=TRUE)
write.xlsx2(cluster3_wohnort_zufriedenheit, "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/Deskription_cluster.xlsx", sheetName="kcluster3_wohnort_zufriedenheit", append=TRUE)



##################################################################################x
####Kapitel 4: Individuelle Faktoren und die Verkehrsmittelwahl in der Freizeit####
##################################################################################x

####Datensatz laden und aufbereiten####
rm(list = ls())
data_cluster <- read.csv(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/D_cluster.csv", header=TRUE, sep=",") #Datensatz mit Cluster-Zuordnungen laden
data_cluster$WT <- NULL
data_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Rohdaten/Datensatz_Erhebung_Treiber des Freizeitverkehrs_inklPLZ.sav",to.data.frame=FALSE,use.value.labels=FALSE) #Datensatz der eigenen Erhebung, inkl. Variable PLZ wird geladen
data <- as.data.frame(data_roh)
data_varlabel <- attr(data_roh,"variable.labels") #Liste mit Variablenlabels erstellen
data_varlabel <- as.data.frame(data_varlabel)
data_valuelabel <- attr(data_roh,"label.table") #Liste mit Wertelabels erstellen
data_roh <- NULL
data <- merge(data, data_cluster, by="IDNR", all=T) #Datensatz der Cluster-Analyse mit Befragungsdatensatz mergen
data_cluster <- NULL
data_staedtchar <- read.csv(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Rohdaten/Raum_mit_staedtischem_Charakter_2016.csv", header=TRUE, sep=";") #Datensatz zu Gemeindezuordnung Stadt/Land laden und mit Befragungsdatensatz mergen
data_staedtchar <- aggregate(data_staedtchar, by=list(data_staedtchar$plz), FUN=min)
data_staedtchar <- rename(data_staedtchar,c("plz"="PLZ"))
data <- left_join(data,data_staedtchar,by="PLZ")
data_staedtchar <- NULL


####Aufbereitung der abh�ngigen Variablen####
#F�r Variablen- und Wertelabels vgl. erstellte Listen

#Abh�ngige Variable: Verkehrsmittel f�r Gastronomiebesuch
data$vm_gastro <- data$Q11 

#Abh�ngige Variable: Verkehrsmittel f�r kulturelle Veranstaltungen/sportlicher Anlass
data$vm_veranstaltung <- data$Q21 

#Abh�ngige Variable: Verkehrsmittel f�r soziale Kontakte (f�r jeden der max. 3 angegebenen Kontakte)
table(data$Q86) 
data$vm_kontakt1[data$Q83==1] <- 1 #Kontakt Nr. 1; 1 = LV
data$vm_kontakt1[data$Q83==2] <- 1 
data$vm_kontakt1[data$Q83==3] <- 11 #11 = MIV
data$vm_kontakt1[data$Q83==4] <- 11 
data$vm_kontakt1[data$Q83==5] <- 111 #111 = �V
data$vm_kontakt1[data$Q83==6] <- 111 
data$vm_kontakt1[data$Q83==7] <- 111  
data$vm_kontakt1[data$Q83==8] <- 111 
data$vm_kontakt1[data$Q83==9] <- 111
data$vm_kontakt1[data$Q83==10] <- 111 
data$vm_kontakt1[data$Q83==11] <- NA 
data$vm_kontakt2[data$Q86==1] <- 1 #Kontakt Nr. 2
data$vm_kontakt2[data$Q86==2] <- 1 
data$vm_kontakt2[data$Q86==3] <- 11
data$vm_kontakt2[data$Q86==4] <- 11 
data$vm_kontakt2[data$Q86==5] <- 111
data$vm_kontakt2[data$Q86==6] <- 111
data$vm_kontakt2[data$Q86==7] <- 111 
data$vm_kontakt2[data$Q86==8] <- 111 
data$vm_kontakt2[data$Q86==9] <- 111 
data$vm_kontakt2[data$Q86==10] <- 111 
data$vm_kontakt2[data$Q86==11] <- NA
data$vm_kontakt3[data$Q89==1] <- 1 #Kontakt Nr. 3
data$vm_kontakt3[data$Q89==2] <- 1 
data$vm_kontakt3[data$Q89==3] <- 11
data$vm_kontakt3[data$Q89==4] <- 11 
data$vm_kontakt3[data$Q89==5] <- 111 
data$vm_kontakt3[data$Q89==6] <- 111
data$vm_kontakt3[data$Q89==7] <- 111
data$vm_kontakt3[data$Q89==8] <- 111
data$vm_kontakt3[data$Q89==9] <- 111 
data$vm_kontakt3[data$Q89==10] <- 111 
data$vm_kontakt3[data$Q89==11] <- NA
data$vm_kontakte2 <- data %>% select(contains("vm_kontakt")) %>% apply(1, median, na.rm = T) # Median pro Person berechnen; bei apply auf 1 setzen um zeilenweise Berechnung durchzuf�hren (2 w�re spaltenweise)
table(data$vm_kontakte2)
data$vm_kontakte2[data$vm_kontakte2==6] <- NA
data$vm_kontakte2[data$vm_kontakte2==56] <- NA
data$vm_kontakte2[data$vm_kontakte2==61] <- NA
table(data$vm_kontakte2)
data$vm_kontakte[data$vm_kontakte2==1] <- 1 #Kodierung 1, 11, 11 in 1, 2, 3 umwandeln
data$vm_kontakte[data$vm_kontakte2==11] <- 2
data$vm_kontakte[data$vm_kontakte2==111] <- 3
data$vm_kontakte[data$vm_kontakte2=="NaN"] <- NA

#Abh�ngige Variable: Anzahl Tagesreisen pro Monat
data$anzahl_tagesreisen <- data$Q51_1 + data$Q51_2 + data$Q51_3 + data$Q51_4 + data$Q51_5 + data$Q51_6

#Abh�ngige Variable: Anzahl Reisen mit �bernachtung pro Jahr
data$anzahl_reisen_uebernachtung <- data$Q61_1 + data$Q61_2 + data$Q61_3 + data$Q61_4 + data$Q61_5 + data$Q61_6

#Abh�ngige Variable: Anzahl Fl�ge
data$flug <- data$Q62_1 + data$Q62_2 + data$Q62_3



####Aufbereitung der unabh�ngigen Variablen####
#F�r Variablen- und Wertelabels vgl. erstellte Listen

#Wohnregion
data$wohnregion[data$raum_staedt_char==0] <- 3
data$wohnregion[data$raum_staedt_char==1] <- 1
data$wohnregion[data$raum_staedt_char==2] <- 1
data$wohnregion[data$raum_staedt_char==3] <- 1
data$wohnregion[data$raum_staedt_char==4] <- 2
data$wohnregion[data$raum_staedt_char==5] <- 2
data$wohnregion[data$raum_staedt_char==6] <- 1
table(data$wohnregion)
data$wohnregion <- as.factor(data$wohnregion)
table(data$wohnregion)
data$wohnregion <- revalue(data$wohnregion, c("1" = "Agglomerationskern", "2" = "Agglomerationsg�rtel", "3" = "Periurban"))
table(data$wohnregion)

#Besitz von OEV-Abo
data$halbtax[data$Q101_3==2] <- 0
data$halbtax[data$Q101_3==1] <- 1
data$halbtax[data$Q101_3==98] <- NA
data$halbtax[data$Q101_3==99] <- NA
data$ga[data$Q101_4==2] <- 0
data$ga[data$Q101_4==1] <- 1
data$ga[data$Q101_4==98] <- NA
data$ga[data$Q101_4==99] <- NA  
data$verbundabo[data$Q101_5==2] <- 0
data$verbundabo[data$Q101_5==1] <- 1
data$verbundabo[data$Q101_5==98] <- NA
data$verbundabo[data$Q101_5==99] <- NA  
data$oev_abo <- with(data, ifelse(data$halbtax==1 | data$ga ==1 | data$verbundabo==1, 1, 0))
data$oev_abo <- as.factor(data$oev_abo)
table(data$oev_abo)
data$oev_abo <- revalue(data$oev_abo, c("0" = "Nein", "1" = "Ja"))
table(data$oev_abo)

#Mobility-Mitgliedschaft
data$mobility[data$Q101_6==2] <- 0
data$mobility[data$Q101_6==1] <- 1
data$mobility[data$Q101_6==98] <- NA
data$mobility[data$Q101_6==99] <- NA  
data$mobility <- as.factor(data$mobility)
table(data$mobility)
data$mobility <- revalue(data$mobility, c("0" = "Nein", "1" = "Ja"))
table(data$mobility)

#PW-Zugriff
data$pw[data$Q102==1] <- 0
data$pw[data$Q102==2] <- 1
data$pw[data$Q102==3] <- 1
data$pw[data$Q102==98] <- NA
data$pw <- as.factor(data$pw)
table(data$pw)
data$pw <- revalue(data$pw, c("0" = "Nein", "1" = "Ja"))
table(data$pw)

#Wohnform
data <- rename(data,c(Q103="wohnform"))
data$wohnform[data$wohnform==96] <- 5
data$wohnform[data$wohnform==98] <- NA
data$wohnform[data$wohnform==99] <- NA
data$wohnform <- as.factor(data$wohnform)
table(data$wohnform)
data$wohnform <- revalue(data$wohnform, c("1" = "Wohnt allein", "2" = "Wohnt mit Lebenspartner/-in", "3" = "Wohnt mit Familie",
                                          "4" = "Wohnt in WG", "5" = "Andere Wohnform"))
table(data$wohnform)


#Zufriedenheit mit Wohnort
data$wohnort_zufriedenheit[data$Q104==1] <- 4
data$wohnort_zufriedenheit[data$Q104==2] <- 3
data$wohnort_zufriedenheit[data$Q104==3] <- 2
data$wohnort_zufriedenheit[data$Q104==4] <- 1
data$wohnort_zufriedenheit[data$Q104==98] <- NA
data$wohnort_zufriedenheit[data$Q104==99] <- NA


#Entfernung Haltestelle
data <- rename(data,c(Q105_1="haltestelle_entfernung"))
table(data$haltestelle_entfernung)
data$haltestelle_entfernung[data$haltestelle_entfernung>2000] <- NA
table(data$haltestelle_entfernung)

#Alter
table(data$AGEHELP)
data$AGEHELP[data$AGEHELP<18] <- NA
data <- rename(data,c(AGEHELP="alter"))
table(data$alter)

#Weiblich
data$weiblich[data$SEX==1] <- 0
data$weiblich[data$SEX==2] <- 1
data$weiblich <- as.factor(data$weiblich)
table(data$weiblich)
data$weiblich <- revalue(data$weiblich, c("0" = "M�nnlich", "1" = "Weiblich"))
table(data$weiblich)

#Einkommen
data <- rename(data,c(Q1011="einkommen"))
data$einkommen[data$einkommen==98] <- NA
data$einkommen[data$einkommen==99] <- NA
data$einkommen <- as.factor(data$einkommen)
table(data$einkommen)
data$einkommen <- revalue(data$einkommen, c("1" = "unter 2'000 CHF", "2" = "2'000 bis 4'000 CHF",
                                            "3" = "4'001 bis 6'000 CHF", 
                                            "4" = "6'001 bis 10'000 CHF", "5" = "�ber 10'000 CHF"))
table(data$einkommen)

#Terti�rer Abschluss
data$tertiaer[data$Q1012==1] <- 0 
data$tertiaer[data$Q1012==2] <- 0
data$tertiaer[data$Q1012==3] <- 0
data$tertiaer[data$Q1012==4] <- 0
data$tertiaer[data$Q1012==5] <- 0
data$tertiaer[data$Q1012==6] <- 1
data$tertiaer[data$Q1012==7] <- 0
data$tertiaer[data$Q1012==96] <- 0
data$tertiaer[data$Q1012==98] <- NA
data$tertiaer[data$Q1012==99] <- NA
data$tertiaer <- as.factor(data$tertiaer)
table(data$tertiaer) 
data$tertiaer <- revalue(data$tertiaer, c("0" = "Nein", "1" = "Ja"))
table(data$tertiaer)


####Durchf�hrung der Regressionsanalysen (Regressionstabellen)####

#Regressionsanalyse Verkehrsmittel Gastronomiebesuch
table(data$vm_gastro) #�bersicht �ber abh�ngige Variable, f�r Wertelabels vgl. Liste mit Wertelabels: Variable "Q11"
data$dv1 <- NULL
data$dv1[data$vm_gastro==1] <- 1 #LV
data$dv1[data$vm_gastro==2] <- 1
data$dv1[data$vm_gastro==3] <- 2 #MIV
data$dv1[data$vm_gastro==4] <- 2
data$dv1[data$vm_gastro==5] <- 3 #�V
data$dv1[data$vm_gastro==6] <- 3
data$dv1[data$vm_gastro==7] <- 3
data$dv1[data$vm_gastro==8] <- 3
data$dv1[data$vm_gastro==9] <- 3
data$dv1[data$vm_gastro==10] <- 3
data$dv1[data$vm_gastro==11] <- NA
data$dv1 <- as.factor(data$dv1)
table(data$dv1)
data$dv1 <- revalue(data$dv1, c("1" = "LV", "2" = "MIV", "3" = "�V"))
data$dv1 <- relevel(data$dv1, ref = "MIV")
m1 <- multinom(dv1 ~ oev_abo + mobility + pw + as.factor(wohnform) + wohnort_zufriedenheit + haltestelle_entfernung + alter + weiblich + tertiaer + as.factor(einkommen) + as.factor(wohnregion), data = data) #Regression durchf�hren
length(m1$weights) #Fallzahl
stargazer(m1, title = "Multinomiale logistische Regression zur Erkl�rung der Wahl des Verkehrsmittels f�r Gastronomiebesuche (Ref.: MIV)", 
          covariate.labels=c("�V-Abo", "Mobility-Mitglied",
                             "Zugriff auf PW", "Wohnt mit Lebenspartner/-in zusammen (Ref.: Wohnt allein)", "Wohnt mit Familie zusammen (Ref.: Wohnt allein)",
                             "Wohnt in einer WG (Ref.: Wohnt allein)", "Andere Wohnform (Ref.: Wohnt allein)", "Zufriedenheit mit Wohnort", 
                             "Entfernung zu n�chster Haltestelle in Meter", "Alter", "Weiblich", "Terti�rer Bildungsabschluss", "Montaseinkommen: 2'000-4'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 4'000-6'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 6'000-10'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: >10'000 CHF (Ref.: <2'000 CHF)", "Agglomerationsg�rtel (Ref.: Agglomerationskern)", "Periurban (Ref.:Agglomerationskern)"), 
          type="html", out="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Regressionstabellen/verkehrsmittel_gastronomiebesuche.html", nobs=TRUE)
summary(m1) #Ergebnis darstellen lassen



#Regressionsanalyse Verkehrsmittel kulturelle Veranstaltungen und Sportanl�sse
table(data$vm_veranstaltung) #�bersicht �ber abh�ngige Variable, f�r Wertelabels vgl. Liste mit Wertelabels: Variable "Q21"
data$dv2[data$vm_veranstaltung==1] <- 1 
data$dv2[data$vm_veranstaltung==2] <- 1
data$dv2[data$vm_veranstaltung==3] <- 2
data$dv2[data$vm_veranstaltung==4] <- 2
data$dv2[data$vm_veranstaltung==5] <- 2
data$dv2[data$vm_veranstaltung==6] <- 3
data$dv2[data$vm_veranstaltung==7] <- 3
data$dv2[data$vm_veranstaltung==8] <- 3
data$dv2[data$vm_veranstaltung==9] <- 3
data$dv2[data$vm_veranstaltung==10] <- 3
data$dv2[data$vm_veranstaltung==11] <- NA
data$dv2 <- as.factor(data$dv2)
table(data$dv2)
data$dv2 <- revalue(data$dv2, c("1" = "LV", "2" = "MIV", "3" = "�V"))
data$dv2 <- relevel(data$dv2, ref = "MIV")
m2 <- multinom(dv2 ~ oev_abo + mobility + pw + as.factor(wohnform) + wohnort_zufriedenheit + haltestelle_entfernung + alter + weiblich + tertiaer + as.factor(einkommen) + as.factor(wohnregion), data = data) #Regression durchf�hren
length(m2$weights) #Fallzahl
stargazer(m2, title = "Multinomiale logistische Regression zur Erkl�rung der Wahl des Verkehrsmittels f�r Besuche von kulturellen Veranstaltungen und Sportanl�ssen (Ref.: MIV)", 
          covariate.labels=c("�V-Abo", "Mobility-Mitglied",
                             "Zugriff auf PW", "Wohnt mit Lebenspartner/-in zusammen (Ref.: Wohnt allein)", "Wohnt mit Familie zusammen (Ref.: Wohnt allein)",
                             "Wohnt in einer WG (Ref.: Wohnt allein)", "Andere Wohnform (Ref.: Wohnt allein)", "Zufriedenheit mit Wohnort", 
                             "Entfernung zu n�chster Haltestelle in Meter", "Alter", "Weiblich", "Terti�rer Bildungsabschluss", "Montaseinkommen: 2'000-4'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 4'000-6'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 6'000-10'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: >10'000 CHF (Ref.: <2'000 CHF)", "Agglomerationsg�rtel (Ref.: Agglomerationskern)", "Periurban (Ref.:Agglomerationskern)"), 
          type="html", out="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Regressionstabellen/verkehrsmittel_veranstaltungen.html")


#Regressionsanalyse Verkehrsmittel soziale Kontakte
table(data$vm_kontakte)
data$dv3 <- as.factor(data$vm_kontakte)
data$dv3 <- revalue(data$dv3, c("1" = "LV", "2" = "MIV", "3" = "�V")) #Wertelabels f�r abh�ngige Variable setzen
table(data$dv3)
data$dv3 <- relevel(data$dv3, ref = "MIV")
m3 <- multinom(dv3 ~ oev_abo + mobility + pw + as.factor(wohnform) + wohnort_zufriedenheit + haltestelle_entfernung + alter + weiblich + tertiaer + as.factor(einkommen) + as.factor(wohnregion), data = data) #Regression durchf�hren
summary(m3)
length(m3$weights) #Fallzahl
stargazer(m3, title = "Multinomiale logistische Regression zur Erkl�rung der Wahl des Verkehrsmittels beim Pflegen von sozialen Kontakten (Ref.: MIV)", 
          covariate.labels=c("�V-Abo", "Mobility-Mitglied",
                             "Zugriff auf PW", "Wohnt mit Lebenspartner/-in zusammen (Ref.: Wohnt allein)", "Wohnt mit Familie zusammen (Ref.: Wohnt allein)",
                             "Wohnt in einer WG (Ref.: Wohnt allein)", "Andere Wohnform (Ref.: Wohnt allein)", "Zufriedenheit mit Wohnort", 
                             "Entfernung zu n�chster Haltestelle in Meter", "Alter", "Weiblich", "Terti�rer Bildungsabschluss", "Montaseinkommen: 2'000-4'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 4'000-6'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 6'000-10'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: >10'000 CHF (Ref.: <2'000 CHF)", "Agglomerationsg�rtel (Ref.: Agglomerationskern)", "Periurban (Ref.:Agglomerationskern)"), 
          type="html", out="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Regressionstabellen/verkehrsmittel_sozialeKontakte.html")



#Anzahl Tagresreisen
table(data$anzahl_tagesreisen) #�bersicht �ber abh�ngige Variable
m5 <- glm(anzahl_tagesreisen ~ oev_abo + mobility + pw + as.factor(wohnform) + wohnort_zufriedenheit + alter + weiblich + tertiaer + as.factor(einkommen) + as.factor(wohnregion), family="poisson", data=data) #Regression durchf�hren
summary(m5)
length(m5$weights) #Fallzahl
stargazer(m5, title = "Poisson Regression zur Erkl�rung der Anzahl Tagesreisen pro Monat", dep.var.labels="Anzahl Tagesreisen",
          covariate.labels=c("�V-Abo", "Mobility-Mitglied",
                             "Zugriff auf PW", "Wohnt mit Lebenspartner/-in zusammen (Ref.: Wohnt allein)", "Wohnt mit Familie zusammen (Ref.: Wohnt allein)",
                             "Wohnt in einer WG (Ref.: Wohnt allein)", "Andere Wohnform (Ref.: Wohnt allein)", "Zufriedenheit mit Wohnort", 
                             "Alter", "Weiblich", "Terti�rer Bildungsabschluss", "Montaseinkommen: 2'000-4'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 4'000-6'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 6'000-10'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: >10'000 CHF (Ref.: <2'000 CHF)", "Agglomerationsg�rtel (Ref.: Agglomerationskern)", "Periurban (Ref.:Agglomerationskern)"), 
          type="html", out="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Regressionstabellen/anzahl_tagesreisen.html")



#Anzahl Reisen mit �bernachtung
table(data$anzahl_reisen_uebernachtung) #�bersicht �ber abh�ngige Variable
data$anzahl_reisen_uebernachtung[data$anzahl_reisen_uebernachtung>20] <- NA
m6 <- glm(anzahl_reisen_uebernachtung ~ oev_abo + mobility + pw + as.factor(wohnform) + wohnort_zufriedenheit + alter + weiblich + tertiaer + as.factor(einkommen) + as.factor(wohnregion), family="poisson", data=data) #Regression durchf�hren
summary(m6)
length(m6$weights) #Fallzahl
stargazer(m6, title = "Poisson Regression zur Erkl�rung der Anzahl Reisen mit �bernachtung pro Jahr", dep.var.labels="Anzahl Reisen mit �bernachtung",
          covariate.labels=c("�V-Abo", "Mobility-Mitglied",
                             "Zugriff auf PW", "Wohnt mit Lebenspartner/-in zusammen (Ref.: Wohnt allein)", "Wohnt mit Familie zusammen (Ref.: Wohnt allein)",
                             "Wohnt in einer WG (Ref.: Wohnt allein)", "Andere Wohnform (Ref.: Wohnt allein)", "Zufriedenheit mit Wohnort", 
                             "Alter", "Weiblich", "Terti�rer Bildungsabschluss", "Montaseinkommen: 2'000-4'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 4'000-6'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 6'000-10'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: >10'000 CHF (Ref.: <2'000 CHF)", "Agglomerationsg�rtel (Ref.: Agglomerationskern)", "Periurban (Ref.:Agglomerationskern)"), 
          type="html", out="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Regressionstabellen/anzahl_reisen_uebernachtung.html")



#Anzahl Fl�ge
table(data$flug) #�bersicht �ber abh�ngige Variable
data$flug[data$flug>10] <- NA
table(data$flug)
m7 <- glm(flug ~ oev_abo + mobility + pw + as.factor(wohnform) + wohnort_zufriedenheit + alter + weiblich + tertiaer + as.factor(einkommen) + as.factor(wohnregion), family="poisson", data=data)
summary(m7)
length(m7$weights) #Fallzahl
stargazer(m7, title = "Poisson Regression zur Erkl�rung der Anzahl Fl�ge pro Jahr", dep.var.labels="Anzahl Fl�ge",
          covariate.labels=c("�V-Abo", "Mobility-Mitglied",
                             "Zugriff auf PW", "Wohnt mit Lebenspartner/-in zusammen (Ref.: Wohnt allein)", "Wohnt mit Familie zusammen (Ref.: Wohnt allein)",
                             "Wohnt in einer WG (Ref.: Wohnt allein)", "Andere Wohnform (Ref.: Wohnt allein)", "Zufriedenheit mit Wohnort", 
                             "Alter", "Weiblich", "Terti�rer Bildungsabschluss", "Montaseinkommen: 2'000-4'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 4'000-6'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: 6'000-10'000 CHF (Ref.: <2'000 CHF)",
                             "Montaseinkommen: >10'000 CHF (Ref.: <2'000 CHF)", "Agglomerationsg�rtel (Ref.: Agglomerationskern)", "Periurban (Ref.:Agglomerationskern)"), 
          type="html", out="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Regressionstabellen/anzahl_fluege.html")




####Marginal effect plots: Verkehrsmittelwahl allt�gliche Freizeit####
#Nachfolgend werden sogenannte marginal effect plots erstellt und als jpeg-Datei abgespeichert.
#F�hrerausweis und PW-Verf�gbarkeit
a <- plot_model(m1, type="pred",terms=c("pw"), 
                axis.title=c("Verf�gbarkeit eines Autos",""), 
                title= "Gastronomiebesuch", 
                xlab = "Verf�gbarkeit eines Autos",
                legend.title = "",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("pw"), 
                axis.title=c("Verf�gbarkeit eines Autos",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("pw"), 
                axis.title=c("Verf�gbarkeit eines Autos",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_werkzeuge_miv.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: �V-Abo und Mobility-Mitgliedschaft
a <- plot_model(m1, type="pred",terms=c("oev_abo","mobility"), 
                axis.title=c("�V-Abonnement",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Mobility-Mitgliedschaft",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("oev_abo","mobility"), 
                axis.title=c("�V-Abonnement",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Mobility-Mitgliedschaft",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("oev_abo","mobility"), 
                axis.title=c("�V-Abonnement",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Mobility-Mitgliedschaft",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_werkzeuge_oev_mobility.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Wohnort
set_theme(axis.angle.x = 90)
a <- plot_model(m1, type="pred",terms=c("wohnregion"), 
                axis.title=c("Wohnort",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("wohnregion"), 
                axis.title=c("Wohnort",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("wohnregion"), 
                axis.title=c("Wohnort",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_wohnort.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()
set_theme(axis.angle.x = 0)

#Marginal effect plots: Zufriedenheit mit Wohnort
a <- plot_model(m1, type="pred",terms=c("wohnort_zufriedenheit"), 
                axis.title=c("Zufriedenheit mit Wohnort (1=tief, 4=hoch)",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("wohnort_zufriedenheit"), 
                axis.title=c("Zufriedenheit mit Wohnort (1=tief, 4=hoch)",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("wohnort_zufriedenheit"), 
                axis.title=c("Zufriedenheit mit Wohnort (1=tief, 4=hoch)",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_zufriedenheit_wohnort.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Haltestellenentfernung
a <- plot_model(m1, type="pred",terms=c("haltestelle_entfernung[all]"), 
                axis.title=c("Entfernung zur n�chsten �V-Haltestelle in Meter",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("haltestelle_entfernung[all]"), 
                axis.title=c("Entfernung zur n�chsten �V-Haltestelle in Meter",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("haltestelle_entfernung[all]"), 
                axis.title=c("Entfernung zur n�chsten �V-Haltestelle in Meter",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_haltestelle_entfernung.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Wohnform
a <- plot_model(m1, type="pred",terms=c("wohnform"), 
                axis.title=c("Wohnform",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=900, height = 4000, width = 1600)
b <- plot_model(m2, type="pred",terms=c("wohnform"), 
                axis.title=c("Wohnform",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=900, height = 4000, width = 1600)
c <- plot_model(m3, type="pred",terms=c("wohnform"), 
                axis.title=c("Wohnform",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=900, height = 4000, width = 1600)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_wohnform.jpeg", res=900, height = 8000, width = 22000)
grid.arrange(a,b,c,nrow=3)
dev.off()

#Marginal effect plots: Soziodemografie
a <- plot_model(m1, type="pred",terms=c("alter", "weiblich"), 
                axis.title=c("Alter",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Geschlecht",
                show.legend = T,
                ci.lvl=0.95,
                x.axis.lim=c(18,80),
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("alter", "weiblich"), 
                axis.title=c("Alter",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Geschlecht",
                show.legend = T,
                ci.lvl=0.95,
                x.axis.lim=c(18,80),
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("alter", "weiblich"), 
                axis.title=c("Alter",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Geschlecht",
                ci.lvl=0.95,
                x.axis.lim=c(18,80),
                axis.lim = c(0,1),
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_soziodemografie.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Sozio�konomie
set_theme(axis.angle.x = 90)
a <- plot_model(m1, type="pred",terms=c("einkommen", "tertiaer"), 
                axis.title=c("Einkommen",""), 
                title= "Gastronomiebesuch", 
                xlab = "",
                legend.title = "Terti�re Ausbildung",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=900, height = 3000, width = 3000)
b <- plot_model(m2, type="pred",terms=c("einkommen", "tertiaer"), 
                axis.title=c("Einkommen",""), 
                title= "Kulturelle Veranstaltung/Sportanlass", 
                xlab = "",
                legend.title = "Terti�re Ausbildung",
                show.legend = T,
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=900, height = 3000, width = 3000)
c <- plot_model(m3, type="pred",terms=c("einkommen", "tertiaer"), 
                axis.title=c("Einkommen",""), 
                title= "Pflege sozialer Kontakte", 
                xlab = "",
                legend.title = "Terti�re Ausbildung",
                ci.lvl=0.95,
                axis.lim = c(0,1),
                res=900, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/alltag_soziooekonomie.jpeg", res=900, height = 6450, width = 21000)
grid.arrange(a,b,c,nrow=1)
dev.off()

####Marginal effect plots: Reisen####
#Marginal effect plots: PW-Verf�gbarkeit
set_theme(axis.angle.x = 0)
a <- plot_model(m5, type="pred",terms=c("pw"), 
                axis.title=c("Verf�gbarkeit eines Autos",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "PW-Verf�gbarkeit",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
b <- plot_model(m6, type="pred",terms=c("pw"), 
                axis.title=c("Verf�gbarkeit eines Autos",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "PW-Verf�gbarkeit",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
c <- plot_model(m7, type="pred",terms=c("pw"), 
                axis.title=c("Verf�gbarkeit eines Autos",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "PW-Verf�gbarkeit",
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/Marginal Effect Plots/reisen_werkzeuge_miv.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: �V-Abo und Mobility-Mitgliedschaft
a <- plot_model(m5, type="pred",terms=c("oev_abo","mobility"), 
                axis.title=c("�V-Abonnement",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "Mobility-Mitgliedschaft",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
b <- plot_model(m6, type="pred",terms=c("oev_abo","mobility"), 
                axis.title=c("�V-Abonnement",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "Mobility-Mitgliedschaft",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
c <- plot_model(m7, type="pred",terms=c("oev_abo","mobility"), 
                axis.title=c("�V-Abonnement",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "Mobility-Mitgliedschaft",
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/reisen_werkzeuge_oev_mobility.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Wohnort
a <- plot_model(m5, type="pred",terms=c("wohnregion"), 
                axis.title=c("Wohnort",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
b <- plot_model(m6, type="pred",terms=c("wohnregion"), 
                axis.title=c("Wohnort",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
c <- plot_model(m7, type="pred",terms=c("wohnregion"), 
                axis.title=c("Wohnort",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/reisen_wohnort.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Zufriedenheit mit Wohnort
a <- plot_model(m5, type="pred",terms=c("wohnort_zufriedenheit"), 
                axis.title=c("Zufriedenheit mit Wohnort (1=tief, 4=hoch)",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
b <- plot_model(m6, type="pred",terms=c("wohnort_zufriedenheit"), 
                axis.title=c("Zufriedenheit mit Wohnort (1=tief, 4=hoch)",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
c <- plot_model(m7, type="pred",terms=c("wohnort_zufriedenheit"), 
                axis.title=c("Zufriedenheit mit Wohnort (1=tief, 4=hoch)",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/reisen_zufriedenheit_wohnort.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Wohnform
a <- plot_model(m5, type="pred",terms=c("wohnform"), 
                axis.title=c("Wohnform",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 5000, width = 2000)
b <- plot_model(m6, type="pred",terms=c("wohnform"), 
                axis.title=c("Wohnform",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "Wohnort",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 5000, width = 2000)
c <- plot_model(m7, type="pred",terms=c("wohnform"), 
                axis.title=c("Wohnform",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "Wohnort",
                ci.lvl=NA,
                res=600, height = 5000, width = 2000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/reisen_wohnform.jpeg", res=600, height = 10000, width = 9000)
grid.arrange(a,b,c,nrow=3)
dev.off()

#Marginal effect plots: Soziodemografie
a <- plot_model(m5, type="pred",terms=c("alter", "weiblich"), 
                axis.title=c("Alter",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "Geschlecht",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
b <- plot_model(m6, type="pred",terms=c("alter", "weiblich"), 
                axis.title=c("Alter",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "Geschlecht",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
c <- plot_model(m7, type="pred",terms=c("alter", "weiblich"), 
                axis.title=c("Alter",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "Geschlecht",
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/reisen_soziodemografie.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()

#Marginal effect plots: Sozio�konomie
set_theme(axis.angle.x = 90)
a <- plot_model(m5, type="pred",terms=c("einkommen", "tertiaer"), 
                axis.title=c("Einkommen",""), 
                title= "Anzahl Tagesreisen pro Monat", 
                xlab = "",
                legend.title = "Terti�re Ausbildung",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
b <- plot_model(m6, type="pred",terms=c("einkommen", "tertiaer"), 
                axis.title=c("Einkommen",""), 
                title= "Anzahl Reisen mit �bernachtung pro Jahr", 
                xlab = "",
                legend.title = "Terti�re Ausbildung",
                show.legend = T,
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
c <- plot_model(m7, type="pred",terms=c("einkommen", "tertiaer"), 
                axis.title=c("Einkommen",""), 
                title= "Anzahl Flugreisen pro Jahr", 
                xlab = "",
                legend.title = "Terti�re Ausbildung",
                ci.lvl=NA,
                res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Regressionsanalysen/Marginal Effect Plots/reisen_soziooekonomie.jpeg", res=600, height = 4300, width = 9000)
grid.arrange(a,b,c,nrow=1)
dev.off()



###################################################x
####Kapitel 5: Verhaltens�konomische Experimente####
###################################################x


####Datensatz aufbereiten####
rm(list = ls())
data_cluster <- read.csv(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Cluster Analyse/Excel Outputs/D_Cluster.csv", header=TRUE, sep=",") #Datensatz der mit Zuordnungen zu Cluster laden
data_cluster$WT <- NULL
data_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Rohdaten/Datensatz_Erhebung_Treiber des Freizeitverkehrs.sav",to.data.frame=FALSE,use.value.labels=FALSE) #Datensatz der eigenen Erhebung laden
data <- as.data.frame(data_roh)
data_varlabel <- attr(data_roh,"variable.labels") #Liste mit Variablenlabels erstellen
data_varlabel <- as.data.frame(data_varlabel)
data_valuelabel <- attr(data_roh,"label.table") #Liste mit Wertelabels erstellen
data_roh <- NULL
data <- merge(data, data_cluster, by="IDNR", all=T) #Datens�tze mergen

#Variable Alter erstellen
data <- rename(data,c(AGEHELP="alter"))

#Variable Weiblich erstellen
data$weiblich[data$SEX==1] <- 0
data$weiblich[data$SEX==2] <- 1
data$weiblich <- as.factor(data$weiblich)
table(data$weiblich)
data$weiblich <- revalue(data$weiblich, c("0" = "M�nnlich", "1" = "Weiblich"))
table(data$weiblich)

####Verhaltens�knomisches Experiment 1####
#Nachfolgend werden die verhaltens�konomischen Experimente anhand Kreuztabellen ausgewertet. Zus�tzlich werden Auswertungen nach Alter und Geschlecht anhand von Plots vorgenommen. 
exp1_tab <- crosstab(data$EXPERIMENT_1, data$D01_ANTWORT,prop.r = TRUE)
exp1_tab
chisq.test(data$EXPERIMENT_1, data$D01_ANTWORT)
table(data$D01_ANTWORT)
data$dv1[data$D01_ANTWORT==1] <- 0
data$dv1[data$D01_ANTWORT==2] <- 1
table(data$dv1)
exp1_logit <- glm(dv1 ~ 1 + as.factor(EXPERIMENT_1) + as.factor(weiblich) + alter,family=binomial(link='logit'),data=data)
exp1geschlecht <- plot_model(exp1_logit, type="pred",terms=c("weiblich", "EXPERIMENT_1"), 
                             axis.title=c("Geschlecht",""), 
                             title= "Wahrscheinlichkeit f�r Ferien im Ausland", 
                             xlab = "",
                             legend.title = "Frame",
                             show.legend = T,
                             ci.lvl=F,
                             axis.lim = c(0,1),
                             res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp1_geschlecht.jpeg", res=600, height = 3000, width = 3000)
exp1geschlecht
dev.off()
exp1alter <- plot_model(exp1_logit, type="pred",terms=c("alter", "EXPERIMENT_1"), 
                        axis.title=c("Alter",""), 
                        title= "Wahrscheinlichkeit f�r Ferien im Ausland", 
                        xlab = "",
                        legend.title = "Frame",
                        show.legend = T,
                        ci.lvl=F,
                        axis.lim = c(0,1),
                        res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp1_alter.jpeg", res=600, height = 3000, width = 3000)
exp1alter
dev.off()

####Verhaltens�knomisches Experiment 2####
exp2_tab <- crosstab(data$EXPERIMENT_2, data$D02_ANTWORT,prop.r = TRUE)
exp2_tab
chisq.test(data$EXPERIMENT_2, data$D02_ANTWORT)
table(data$D02_ANTWORT)
data$dv2[data$D02_ANTWORT==1] <- 0
data$dv2[data$D02_ANTWORT==2] <- 1
table(data$dv2)
exp2_logit <- glm(dv2 ~ 1 + as.factor(EXPERIMENT_2) + as.factor(weiblich) + alter,family=binomial(link='logit'),data=data)
exp2geschlecht <- plot_model(exp2_logit, type="pred",terms=c("weiblich", "EXPERIMENT_2"), 
                             axis.title=c("Geschlecht",""), 
                             title= "Wahrscheinlichkeit f�r 'zu Fuss'", 
                             xlab = "",
                             legend.title = "Frame",
                             show.legend = T,
                             ci.lvl=F,
                             axis.lim = c(0,1),
                             res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp2_geschlecht.jpeg", res=600, height = 3000, width = 3000)
exp2geschlecht
dev.off()
exp2alter <- plot_model(exp2_logit, type="pred",terms=c("alter", "EXPERIMENT_2"), 
                        axis.title=c("Alter",""), 
                        title= "Wahrscheinlichkeit f�r 'zu Fuss'", 
                        xlab = "",
                        legend.title = "Frame",
                        show.legend = T,
                        ci.lvl=F,
                        axis.lim = c(0,1),
                        res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp2_alter.jpeg", res=600, height = 3000, width = 3000)
exp2alter
dev.off()


####Verhaltens�knomisches Experiment 3####
exp3_tab <- crosstab(data$EXPERIMENT_3, data$D03_ANTWORT,prop.r = TRUE)
exp3_tab
chisq.test(data$EXPERIMENT_3, data$D03_ANTWORT)
table(data$D03_ANTWORT)
data$dv3[data$D03_ANTWORT==1] <- 0
data$dv3[data$D03_ANTWORT==2] <- 1
table(data$dv3)
exp3_logit <- glm(dv3 ~ 1 + as.factor(EXPERIMENT_3) + as.factor(weiblich) + alter,family=binomial(link='logit'),data=data)
exp3geschlecht <- plot_model(exp3_logit, type="pred",terms=c("weiblich", "EXPERIMENT_3"), 
                             axis.title=c("Geschlecht",""), 
                             title= "Wahrscheinlichkeit f�r 'Zug'", 
                             xlab = "",
                             legend.title = "Frame",
                             show.legend = T,
                             ci.lvl=F,
                             axis.lim = c(0,1),
                             res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp3_geschlecht.jpeg", res=600, height = 3000, width = 3000)
exp3geschlecht
dev.off()
exp3alter <- plot_model(exp3_logit, type="pred",terms=c("alter", "EXPERIMENT_3"), 
                        axis.title=c("Alter",""), 
                        title= "Wahrscheinlichkeit f�r 'Zug'", 
                        xlab = "",
                        legend.title = "Frame",
                        show.legend = T,
                        ci.lvl=F,
                        axis.lim = c(0,1),
                        res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp3_alter.jpeg", res=600, height = 3000, width = 3000)
exp3alter
dev.off()


####Verhaltens�knomisches Experiment 4####
exp4_tab <- crosstab(data$EXPERIMENT_4, data$D04_ANTWORT,prop.r = TRUE)
exp4_tab
chisq.test(data$EXPERIMENT_4, data$D04_ANTWORT)
table(data$D04_ANTWORT)
data$dv4[data$D04_ANTWORT==1] <- 0
data$dv4[data$D04_ANTWORT==2] <- 1
table(data$dv4)
exp4_logit <- glm(dv4 ~ 1 + as.factor(EXPERIMENT_4) + as.factor(weiblich) + alter,family=binomial(link='logit'),data=data)
exp4geschlecht <- plot_model(exp4_logit, type="pred",terms=c("weiblich", "EXPERIMENT_4"), 
                             axis.title=c("Geschlecht",""), 
                             title= "Wahrscheinlichkeit f�r '�V'", 
                             xlab = "",
                             legend.title = "Frame",
                             show.legend = T,
                             ci.lvl=F,
                             axis.lim = c(0,1),
                             res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp4_geschlecht.jpeg", res=600, height = 3000, width = 3000)
exp4geschlecht
dev.off()
exp4alter <- plot_model(exp4_logit, type="pred",terms=c("alter", "EXPERIMENT_4"), 
                        axis.title=c("Alter",""), 
                        title= "Wahrscheinlichkeit f�r '�V'", 
                        xlab = "",
                        legend.title = "Frame",
                        show.legend = T,
                        ci.lvl=F,
                        axis.lim = c(0,1),
                        res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp4_alter.jpeg", res=600, height = 3000, width = 3000)
exp4alter
dev.off()



####Verhaltens�knomisches Experiment 5####
exp5_tab <- crosstab(data$EXPERIMENT_5, data$D05_ANTWORT,prop.r = TRUE)
exp5_tab
chisq.test(data$EXPERIMENT_5, data$D05_ANTWORT)
table(data$D05_ANTWORT)
data$dv5[data$D05_ANTWORT==1] <- 0
data$dv5[data$D05_ANTWORT==2] <- 1
table(data$dv5)
exp5_logit <- glm(dv5 ~ 1 + as.factor(EXPERIMENT_5) + as.factor(weiblich) + alter,family=binomial(link='logit'),data=data)
exp5geschlecht <- plot_model(exp5_logit, type="pred",terms=c("weiblich", "EXPERIMENT_5"), 
                             axis.title=c("Geschlecht",""), 
                             title= "Wahrscheinlichkeit f�r '�V'", 
                             xlab = "",
                             legend.title = "Frame",
                             show.legend = T,
                             ci.lvl=F,
                             axis.lim = c(0,1),
                             res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp5_geschlecht.jpeg", res=600, height = 3000, width = 3000)
exp5geschlecht
dev.off()
exp5alter <- plot_model(exp5_logit, type="pred",terms=c("alter", "EXPERIMENT_5"), 
                        axis.title=c("Alter",""), 
                        title= "Wahrscheinlichkeit f�r '�V'", 
                        xlab = "",
                        legend.title = "Frame",
                        show.legend = T,
                        ci.lvl=F,
                        axis.lim = c(0,1),
                        res=600, height = 3000, width = 3000)
jpeg("P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Verhaltensoekonomische Experimente/Plots/exp5_alter.jpeg", res=600, height = 3000, width = 3000)
exp5alter
dev.off()



#################################################x
####Kapitel 6: Kategorien des Freizeitverkehrs####
#################################################x

####Aufbereitung des Datensatzes####
wege_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/Rohdaten/MZ_2015/wegeinland.sav",to.data.frame=FALSE,use.value.labels=FALSE) # Datensatz Wege laden
wege <- as.data.frame(wege_roh)
wege_varlabel <- attr(wege_roh,"variable.labels")
wege_varlabel <- as.data.frame(wege_varlabel)
wege_valuelabel <- attr(wege_roh,"label.table")

etappen_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/Rohdaten/MZ_2015/etappen.sav",to.data.frame=FALSE,use.value.labels=FALSE) # Datensatz Etappen laden
etappen <- as.data.frame(etappen_roh)
etappen <- etappen[ which(etappen$E_Ausland==2), ] #Nur Inlandetappen
etappen_varlabel <- attr(etappen_roh,"variable.labels")
etappen_varlabel <- as.data.frame(etappen_varlabel)
etappen_valuelabel <- attr(etappen_roh,"label.table")

zielpersonen_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/Rohdaten/MZ_2015/zielpersonen.sav",to.data.frame=FALSE,use.value.labels=FALSE) # Datensatz Zielpersonen laden
zielpersonen <- as.data.frame(zielpersonen_roh)
zielpersonen_varlabel <- attr(zielpersonen_roh,"variable.labels")
zielpersonen_varlabel <- as.data.frame(zielpersonen_varlabel)
zielpersonen_valuelabel <- attr(zielpersonen_roh,"label.table")

haushalte_roh <- read.spss("P:/P18-52Freizeitverkehr_SVI/Erhebungen/Rohdaten/MZ_2015/haushalte.sav",to.data.frame=FALSE,use.value.labels=FALSE) # Datensatz Haushalte laden
haushalte <- as.data.frame(haushalte_roh)
haushalte_varlabel <- attr(haushalte_roh,"variable.labels")
haushalte_varlabel <- as.data.frame(haushalte_varlabel)
haushalte_valuelabel <- attr(haushalte_roh,"label.table")


#Distanzen pro Verkehrsmittel respektive Kategorie aggregieren und als neuen Datensatz abspeichern#
#MIV: Mofa (3), Kleinmotorrad (4), Motorrad als Fahrer (5), Motorrad als Mitfahrer (6), Auto als Fahrer (7), Auto als Mitfahrer (8)
etappen$miv <- with(etappen, ifelse(f51300==3|f51300==4|f51300==5|f51300==6|f51300==7|f51300==8, etappen$rdist,0))
etappen$miv[etappen$f51300==-99|etappen$f51300==-98|etappen$f51300==-97|etappen$f51300==95|etappen$f51300==95] <- NA
#OEV: Bahn/Zug (9), Postauto (10), Bus/Schulbus (11), Tram/Metro (12)
etappen$oev <- with(etappen, ifelse(f51300==9|f51300==10|f51300==11|f51300==12, etappen$rdist,0))
etappen$oev[etappen$f51300==-99|etappen$f51300==-98|etappen$f51300==-97|etappen$f51300==95|etappen$f51300==95] <- NA
#LV: Zu Fuss (1), Velo (2), E-Bike ohne Kontrollschild (20), E-Bike mit gelbem Kontrolschild (21)
etappen$lv <- with(etappen, ifelse(f51300==1|f51300==2|f51300==20|f51300==21, etappen$rdist,0))
etappen$lv[etappen$f51300==-99|etappen$f51300==-98|etappen$f51300==-97|etappen$f51300==95|etappen$f51300==95] <- NA
#Uebrige: Taxi (13), Reisecar (14), Lastwagen (15), Schiff/Boot (16), Flugzeug/Luftfahrzeug (17), Zahnradbahn, Standseilbahn, Seilbahn, Sessellift, Skilift (18), F�G (19)
etappen$uebrige <- with(etappen, ifelse(f51300==13|f51300==14|f51300==15|f51300==16|f51300==17|f51300==18|f51300==19, etappen$rdist,0))
etappen$uebrige[etappen$f51300==-99|etappen$f51300==-98|etappen$f51300==-97|etappen$f51300==95|etappen$f51300==95] <- NA
#Check ob Umkodierung geklappt hat.
favstats(etappen$miv~etappen$f51300, data = etappen)
favstats(etappen$oev~etappen$f51300, data = etappen)
favstats(etappen$lv~etappen$f51300, data = etappen)
favstats(etappen$uebrige~etappen$f51300, data = etappen)
#Der Datensatz wird reduziert: Es werden nur die  soeben erstellten Variablen sowie die Identifikationsvariablen und Gewichtungsvariablen behalten.
keeps <- c("HHNR", "WP", "miv", "oev", "lv", "uebrige", "WP", "WEGNR")
etappen = etappen[keeps]

#Nun werden die Distanzen f�r die Verkehrsmittel pro Weg aggregiert.
miv <- aggregate(etappen$miv, by=list(etappen$HHNR, etappen$WP, etappen$WEGNR), FUN=sum, na.rm=TRUE)
oev <- aggregate(etappen$oev, by=list(etappen$HHNR, etappen$WP, etappen$WEGNR), FUN=sum, na.rm=TRUE)
lv <- aggregate(etappen$lv, by=list(etappen$HHNR, etappen$WP, etappen$WEGNR), FUN=sum, na.rm=TRUE)
uebrige <- aggregate(etappen$uebrige, by=list(etappen$HHNR, etappen$WP, etappen$WEGNR), FUN=sum, na.rm=TRUE)

#Die Variable "Group.1" wurde in HHNR umgewandelt. Diese wird wieder zur�ckbenannt.
miv$HHNR <- miv$Group.1
oev$HHNR <- oev$Group.1
lv$HHNR <- lv$Group.1
uebrige$HHNR <- uebrige$Group.1

#Die Variable "Group.2" wurde in WP umgewandelt. Diese wird wieder zur�ckbenannt.
miv$WP <- miv$Group.2
oev$WP <- oev$Group.2
lv$WP <- lv$Group.2
uebrige$WP <- uebrige$Group.2

#Die Variable "Group.3" wurde in WEGNR umgewandelt. Diese wird wieder zur�ckbenannt.
miv$WEGNR <- miv$Group.3
oev$WEGNR <- oev$Group.3
lv$WEGNR <- lv$Group.3
uebrige$WEGNR <- uebrige$Group.3

#Die aggregierten Distanzen pro Verkehrsmittel werden als "X" benannt. Die Variablen sollen wieder erkennbar umbenannt werden.
miv$miv <- miv$x
oev$oev <- oev$x
lv$lv <- lv$x
uebrige$uebrige <- uebrige$x

#Die Variablen mit den alten Variablenbezeichnungen werden gel�scht um Ordnung zu schaffen. 
miv$Group.1 <- NULL
oev$Group.1 <- NULL
lv$Group.1 <- NULL
uebrige$Group.1 <- NULL

miv$Group.2 <- NULL
oev$Group.2 <- NULL
lv$Group.2 <- NULL
uebrige$Group.2 <- NULL

miv$Group.3 <- NULL
oev$Group.3 <- NULL
lv$Group.3 <- NULL
uebrige$Group.3 <- NULL

miv$x <- NULL
oev$x <- NULL
lv$x <- NULL
uebrige$x <- NULL

#Nun werden die Distanzen pro Verkehrsmittel f�r die einzelnen Wege "gemergt"
distanzen_wege <- miv
distanzen_wege <- merge(distanzen_wege, oev, by=c("HHNR","WP","WEGNR"), all=T)
distanzen_wege <- merge(distanzen_wege, lv, by=c("HHNR","WP","WEGNR"), all=T)
distanzen_wege <- merge(distanzen_wege, uebrige, by=c("HHNR","WP","WEGNR"), all=T)
#Jetzt liegt mit "distanzen_wege" der Datensatz mit den Distanzen f�r die einzelnen Verkehrsmittel auf Ebene des Wegs vor. Jetzt wird mal ein bisschen aufger�umt mit all den Datens�tzen, bevor es mit dem Wege-Datensatz weitergeht.
etappen <- NULL
etappen_roh <- NULL
etappen_valuelabel <- NULL
etappen_varlabel <- NULL


#Aufbereitung des Datensatzes Wege
#Variable f�r Wegzweck
wege$zweck[wege$f51700_weg == 1] <- 1 #Besuche bei Verwandten oder Bekannten
wege$zweck[wege$f51700_weg == 2] <- 2 #Gastronomiebesuche
wege$zweck[wege$f51700_weg == 9] <- 3 #Besuche von Kulturveranstaltungen und Freizeitanlagen sowie sportlichen Anl�ssen
wege$zweck[wege$f51700_weg == 7] <- 4 #Nicht sportliche Aussenaktivit�ten (z.B. Spazieren)
wege$zweck[wege$f51700_weg == 6] <- 3 #Besuche von Kulturveranstaltungen und Freizeitanlagen sowie sportlichen Anl�ssen
val_lab(wege$zweck) = num_lab ("1 Besuche bei Verwandten oder Bekannten
                               2 Gastronomiebesuche
                               3 Besuche von Kulturveranstaltungen und Freizeitanlagen sowie sportlichen Anl�ssen
                               4 Nicht sportliche Aussenaktivit�ten (z.B. Spazieren)")

#Variable f�r Raumtyp Startort
wege$start_raumtyp[wege$S_staedt_char_2012==0] <- 3 # 3 = Periurban
wege$start_raumtyp[wege$S_staedt_char_2012==1] <- 1 # 1 = Agglozentrum/Kerngemeinde
wege$start_raumtyp[wege$S_staedt_char_2012==2] <- 1 # 1 = Agglozentrum/Kerngemeinde
wege$start_raumtyp[wege$S_staedt_char_2012==3] <- 1 # 1 = Agglozentrum/Kerngemeinde
wege$start_raumtyp[wege$S_staedt_char_2012==4] <- 2 # 2 = Agglog�rtel
wege$start_raumtyp[wege$S_staedt_char_2012==5] <- 2 # 2 = Agglog�rtel
wege$start_raumtyp[wege$S_staedt_char_2012==6] <- 1 # 1 = Agglozentrum/Kerngemeinde
val_lab(wege$start_raumtyp) = num_lab ("1 Start: Agglozentrum/Kerngemeinde
                                       2 Start: Agglog�rtel
                                       3 Start: Periurban")

#Variable f�r Raumtyp Zielort
wege$ziel_raumtyp[wege$Z_staedt_char_2012==0] <- 3 # 3 = Periurban
wege$ziel_raumtyp[wege$Z_staedt_char_2012==1] <- 1 # 1 = Agglozentrum/Kerngemeinde
wege$ziel_raumtyp[wege$Z_staedt_char_2012==2] <- 1 # 1 = Agglozentrum/Kerngemeinde
wege$ziel_raumtyp[wege$Z_staedt_char_2012==3] <- 1 # 1 = Agglozentrum/Kerngemeinde
wege$ziel_raumtyp[wege$Z_staedt_char_2012==4] <- 2 # 2 = Agglog�rtel
wege$ziel_raumtyp[wege$Z_staedt_char_2012==5] <- 2 # 2 = Agglog�rtel
wege$ziel_raumtyp[wege$Z_staedt_char_2012==6] <- 1 # 1 = Agglozentrum/Kerngemeinde
val_lab(wege$ziel_raumtyp) = num_lab ("1 Ziel: Agglozentrum/Kerngemeinde
                                      2 Ziel: Agglog�rtel
                                      3 Ziel: Periurban")

#Variable f�r mono- vs. multimodal
wege$monomodal[wege$w_etappen == 1] <- 1
wege$monomodal[wege$w_etappen > 1] <- 0  
val_lab(wege$monomodal) = num_lab ("1 Ja, Weg wurde monomodal zur�ckgelegt,
                                   0 Nein, Weg wurde intermodal zur�ckgelegt")

#Variable f�r Anzahl Umsteigevorg�nge
wege$anzahl_umsteigen <- wege$w_etappen - 1 
wege <- wege %>% mutate(anzahl_umsteigen = ifelse(anzahl_umsteigen < 0, NA, anzahl_umsteigen))

#Im Wege-Datensatz wird eine Variable zur Unterwegszeit erstellt.
wege$unterwegszeit <- wege$dauer2
wege <- wege %>% mutate(unterwegszeit = ifelse(unterwegszeit < 0, NA, unterwegszeit))

#Im Wege-Datensatz wird eine Variable Startzeit erstellt.
wege$startzeit <- wege$f51100
wege <- wege %>% mutate(startzeit = ifelse(startzeit < 0, NA, startzeit))

#Im Wege-Datensatz wird eine Variable Startzeit erstellt.
wege$ankunftszeit <- wege$f51400
wege <- wege %>% mutate(ankunftszeit = ifelse(ankunftszeit < 0, NA, ankunftszeit))


#Im Wege-Datensatz wird eine Variable erstellt f�r Wege in und ausserhalb der Stosszeiten.
wege_interest <- wege %>% 
  select(HHNR, WEGNR, startzeit, ankunftszeit, "dauer_mit_umsteigen" = dauer2) %>% 
  mutate(
    langeFahrt = ifelse(dauer_mit_umsteigen > (60*24), 1, 0), #L�nger als 24h Fahrten
    Abfahrtszeit = abs(startzeit), #Es gibt negative Werte
    Abfahrt_time = startzeit/60,
    Ankunft_time = ankunftszeit/60
  )
a <- 7*60
b <- 8.5*60
c <- 17*60
d <- 18*60
wege_interest <- wege_interest %>%  
  mutate(
    stosszeiten = case_when(
      startzeit > b & ankunftszeit < c ~ 0, # Durch den Tag gefahren
      ankunftszeit < a ~ 0, # vor 7:00 angekommen
      startzeit > d ~ 0, # nach 18:00 abgefahren
      TRUE ~ 1 #alles andere Stosszeit
    )
  )
wege <- merge(wege, wege_interest, by=c("HHNR","WEGNR"), all=T)

#Datensatz wird erstellt und abgespeichert.
keeps <- c("HHNR", "WP", "WEGNR", "start_raumtyp", "ziel_raumtyp", "zweck", "monomodal", "anzahl_umsteigen", "unterwegszeit", "Abfahrt_time", "Ankunft_time", "stosszeiten", "wzweck1", "f51700_weg")
wege = wege[keeps]
finaler_datensatz <- merge(wege, distanzen_wege, by=c("HHNR","WP","WEGNR"), all=T)
save(finaler_datensatz, file = "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Auswertungsdatensatz.Rdata")


####Auswertung####
load(file = "P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Auswertungsdatensatz.Rdata")
finaler_datensatz$gesamtdistanz <- finaler_datensatz %>% select(miv, oev, lv, uebrige) %>% 
  apply(1, sum, na.rm=T)

#Anteil Distanzen Freizeitzweck an allen Zwecken
finaler_datensatz$gesamtdistanz_gewichtet <- finaler_datensatz$gesamtdistanz * finaler_datensatz$WP
Tabelle1 <- finaler_datensatz %>%
  group_by(wzweck1) %>%
  summarise(Distanz_summe_gewichtet = sum(gesamtdistanz_gewichtet),
            Distanz_summe_ungewichtet = sum(gesamtdistanz)) 
Tabelle1
Tabelle1 %>% as.data.frame() %>% write.xlsx(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Excel Outputs/Distanzsummen_Zwecke2.xlsx")


#Anteil Distanzen Ausgew�hlte Zwecke an allen Freizeitzwecken
Tabelle2 <- finaler_datensatz %>%
  group_by(f51700_weg) %>%
  summarise(Distanz_summe_gewichtet = sum(gesamtdistanz_gewichtet),
            Distanz_summe_ungewichtet = sum(gesamtdistanz)) 
Tabelle2
Tabelle2 %>% as.data.frame() %>% write.xlsx(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Excel Outputs/Distanzsummen_Freizeitzwecke2.xlsx")


#Auswertung Kategorien nach Distanzen
finaler_datensatz$miv_gewichtet <- finaler_datensatz$miv * finaler_datensatz$WP
finaler_datensatz$oev_gewichtet <- finaler_datensatz$oev * finaler_datensatz$WP
finaler_datensatz$lv_gewichtet <- finaler_datensatz$lv * finaler_datensatz$WP
finaler_datensatz$uebrige_gewichtet <- finaler_datensatz$uebrige * finaler_datensatz$WP
Tabelle3 <- finaler_datensatz %>%
  group_by(zweck, ziel_raumtyp) %>%
  summarise(summeWege_gewichtet = sum(WP),
            summe_Gesamtdistanz = sum(gesamtdistanz),
            durchs_Distanz_MIV = mean(miv),
            durchs_Distanz_OEV = mean(oev),
            durchs_Distanz_LV = mean(lv),
            durchs_Distanz_UEBRIGE = mean(uebrige)) 
Tabelle3
Tabelle3 %>% as.data.frame() %>% write.xlsx(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Excel Outputs/Auswertung_nach_Distanzen2.xlsx")


#Auswertung Kategorien nach Distanzen mit Ber�cksichtigung von Startort
finaler_datensatz$miv_gewichtet <- finaler_datensatz$miv * finaler_datensatz$WP
finaler_datensatz$oev_gewichtet <- finaler_datensatz$oev * finaler_datensatz$WP
finaler_datensatz$lv_gewichtet <- finaler_datensatz$lv * finaler_datensatz$WP
finaler_datensatz$uebrige_gewichtet <- finaler_datensatz$uebrige * finaler_datensatz$WP
Tabelle3b <- finaler_datensatz %>%
  group_by(zweck, ziel_raumtyp, start_raumtyp) %>%
  summarise(summeWege_gewichtet = sum(WP),
            summe_Gesamtdistanz = sum(gesamtdistanz),
            durchs_Distanz_MIV = mean(miv),
            durchs_Distanz_OEV = mean(oev),
            durchs_Distanz_LV = mean(lv),
            durchs_Distanz_UEBRIGE = mean(uebrige)) 
Tabelle3b
Tabelle3b %>% as.data.frame() %>% write.xlsx(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Excel Outputs/Auswertung_nach_Distanzen_mit_Startort.xlsx")




#Auswertung Kategorien nach Unterwegszeit
table(finaler_datensatz$unterwegszeit)
finaler_datensatz$unterwegszeit2 <- finaler_datensatz$unterwegszeit
finaler_datensatz$unterwegszeit2[finaler_datensatz$unterwegszeit2>360] <- NA
table(finaler_datensatz$unterwegszeit2)
finaler_datensatz$unterwegszeit_gewichtet <- finaler_datensatz$unterwegszeit * finaler_datensatz$WP
finaler_datensatz$unterwegszeit2_gewichtet <- finaler_datensatz$unterwegszeit2 * finaler_datensatz$WP
table(finaler_datensatz$unterwegszeit2_gewichtet)
Tabelle4 <- finaler_datensatz %>%
  group_by(zweck, ziel_raumtyp) %>%
  summarise(summeWege_gewichtet = sum(WP),
            durchs_Unterwegszeit = mean(unterwegszeit_gewichtet),
            durchs_Unterwegszeit2 = mean(unterwegszeit2_gewichtet,na.rm=TRUE))
Tabelle4
Tabelle4 %>% as.data.frame() %>% write.xlsx(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Excel Outputs/Auswertung_nach_Unterwegszeit2.xlsx")



#Auswertung Kategorien nach Stosszeiten/Randzeiten
table(finaler_datensatz$stosszeiten)
finaler_datensatz$stosszeiten_gewichtet <- finaler_datensatz$stosszeiten * finaler_datensatz$WP
Tabelle5 <- finaler_datensatz %>%
  group_by(zweck, ziel_raumtyp) %>%
  summarise(summeWege_gewichtet = sum(WP),
            Anteil_Stosszeiten_ungewichtet = mean(stosszeiten),
            Anteil_Stosszeiten_gewichtet = mean(stosszeiten_gewichtet))
Tabelle5
Tabelle5 %>% as.data.frame() %>% write.xlsx(file="P:/P18-52Freizeitverkehr_SVI/Erhebungen/GitHub/Kategorisierung des Freizeitverkehrs/Excel Outputs/Auswertung_nach_Stosszeiten2.xlsx")


